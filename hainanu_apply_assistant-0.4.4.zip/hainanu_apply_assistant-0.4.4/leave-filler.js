(() => {
  const norm=s=>String(s||"").toLowerCase().replace(/[\s\u00a0：:，,（）()【】*?？]/g,"");
  const visible=el=>!!el&&!!(el.getClientRects().length)&&getComputedStyle(el).visibility!=="hidden";
  const setText=(el,value)=>{
    if(!el||el.disabled||el.readOnly) return false;
    const proto=el.tagName==="TEXTAREA"?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    const setter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
    if(!setter)return false;
    setter.call(el,value);el.dispatchEvent(new Event("input",{bubbles:true}));el.dispatchEvent(new Event("change",{bubbles:true}));
    return el.value===value;
  };
  const row=name=>document.querySelector(`[data-field="${CSS.escape(name)}"]`);
  const chooseRadio=(name,value)=>{
    const el=document.querySelector(`input[type="radio"][name="${CSS.escape(name)}"][value="${CSS.escape(value)}"]`);
    if(!el||el.disabled)return false;
    el.click();return el.checked;
  };
  function makeDateList(start,end){
    const valid=s=>typeof s==="string"&&/^\d{4}-\d{2}-\d{2}$/.test(s);
    if(!valid(start)&&!valid(end))return [];
    if(!valid(start)||!valid(end))throw new Error("开始和结束日期必须同时有效，才能推算请假天数。");
    const [sy,sm,sd]=start.split("-").map(Number),[ey,em,ed]=end.split("-").map(Number);
    const from=Date.UTC(sy,sm-1,sd),to=Date.UTC(ey,em-1,ed);
    const validDate=(stamp,y,m,d)=>{const date=new Date(stamp);return date.getUTCFullYear()===y&&date.getUTCMonth()+1===m&&date.getUTCDate()===d;};
    if(!validDate(from,sy,sm,sd)||!validDate(to,ey,em,ed))throw new Error("日期不是有效日历日期。");
    if(from>to)throw new Error("结束日期早于开始日期，请先核对日期。");
    const count=Math.floor((to-from)/86400000)+1;
    if(count>366)throw new Error("日期范围超过366天，未自动选择。");
    return Array.from({length:count},(_,i)=>new Date(from+i*86400000));
  }
  function decodeB64Json(token){
    if(!token)return null;
    try{
      if(token.startsWith("%7B")||token.startsWith("{"))return JSON.parse(decodeURIComponent(token));
      const b64=token.replace(/-/g,"+").replace(/_/g,"/").padEnd(Math.ceil(token.length/4)*4,"=");
      const binary=atob(b64),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
      return JSON.parse(new TextDecoder().decode(bytes));
    }catch{return null;}
  }
  function decodeFileList(token){
    const value=decodeB64Json(token);
    return Array.isArray(value)?value.filter(item=>item&&typeof item.url==="string"&&/^https:\/\//i.test(item.url)):[];
  }
  function decodeDirectPrefill(){
    try{
      const normalized=globalThis.HaiAgentPrefill?.parseUrl(location.href);
      if(normalized?.serviceId==="student_leave"&&normalized.data){
        return {...normalized.data,files:normalized.files||[]};
      }
      const searchParams=new URLSearchParams(location.search);
      const hashQuery=location.hash.includes("?")?location.hash.split("?").slice(1).join("?"):location.hash.replace(/^#/,"");
      const params=searchParams.get("leavePrefill")?searchParams:new URLSearchParams(hashQuery);
      const token=params.get("leavePrefill")||"";
      if(!token)return null;
      let payload=decodeB64Json(token);
      if(!payload)return null;
      if(payload?.data&&typeof payload.data==="object"&&!payload.leaveType)payload=payload.data;
      if(payload?.expiresAt&&Date.now()>Date.parse(payload.expiresAt))return null;
      if(!payload?.leaveType||!payload?.startDate||!payload?.endDate||!payload?.reason)return null;
      const linkFiles=decodeFileList(params.get("leaveFiles"));
      payload.files=Array.isArray(payload.files)?payload.files:linkFiles;
      return payload;
    }catch{return null;}
  }
  function clearDirectPrefill(){
    try{
      const url=new URL(location.href);
      url.searchParams.delete("leavePrefill");
      url.searchParams.delete("leaveFiles");
      if(url.hash.includes("leavePrefill=")){
        const raw=url.hash.slice(1);
        const split=raw.indexOf("?");
        if(split>=0){
          const params=new URLSearchParams(raw.slice(split+1));
          params.delete("leavePrefill");
          params.delete("leaveFiles");
          const query=params.toString();
          url.hash="#"+raw.slice(0,split)+(query?"?"+query:"");
        }
      }
      history.replaceState(null,"",url.toString());
    }catch{}
  }
  async function fillTask(d){
      const url=new URL(location.href);
      if(url.hostname!=="ehall.hainanu.edu.cn"||!url.pathname.startsWith("/xsfw/sys/xsqjapp/"))throw new Error("当前页面不是允许的学生请假应用。");
      const form=document.querySelector("#add-form-qjxx");
      if(!form||!visible(form))throw new Error("没有找到已打开的请假申请表单。");
      const done=[],skipped=[];
      if(d.leaveType==="病假"){
        if(chooseRadio("QJXZ","1"))done.push("请假性质：因私请假");else skipped.push("请假性质：未能选择因私请假");
      }else if(d.leaveType==="事假"){
        if(chooseRadio("QJXZ","1"))done.push("请假性质：因私请假");else skipped.push("请假性质：未能选择因私请假");
      }
      // QJLX can be loaded or refreshed after QJXZ changes. Give the page a
      // moment to finish that dependency before the background script selects it.
      if(d.leaveType==="病假"||d.leaveType==="事假")await wait(250);
      const mode=d.leaveMode==="按节次"?"按节次":"按天";
      const reason=form.querySelector('[data-field="QJSY"] textarea[name="QJSY"]');
      if(d.reason&&setText(reason,d.reason))done.push("请假事由");else skipped.push("请假事由：未识别或控件未接受值");
      if(d.outside==="否"){
        if(chooseRadio("SFLX","0"))done.push("是否出校：否");else skipped.push("是否出校：未能选择");
        if(chooseRadio("SFLKSZD","0"))done.push("是否离开学校所在地：否");else skipped.push("是否离开学校所在地：未能选择");
      }else skipped.push("出校/目的地：识别信息不足，未更改单选项");
      let dateList=[];
      try{dateList=makeDateList(d.startDate,d.endDate);}catch(e){skipped.push("请假日期："+(e.message||String(e)));}
      const pageState=await chrome.runtime.sendMessage({type:"LEAVE_SET_PAGE_FIELDS",data:{leaveType:d.leaveType||"",leaveMode:mode,dates:dateList.map(d=>d.toISOString().slice(0,10)),phone:d.phone||""}}).catch(e=>({ok:false,error:e.message||String(e)}));
      if(!pageState?.ok)skipped.push("请假方式/日历："+(pageState?.error||"页面设置失败"));
      else{
        if(pageState.leaveTypeReady)done.push("请假类型："+pageState.leaveTypeLabel);
        else skipped.push("请假类型："+(pageState.leaveTypeError||"未能设置，请手动选择"));
        done.push("请假方式："+pageState.mode);
        if(pageState.phoneReady)done.push(d.phone?"手机号已填入":"手机号已保留页面预填号码");
        else skipped.push("手机号：必填；对话和登录预填中都未发现有效手机号，请在表单填写");
        if(pageState.mode==="按节次")skipped.push("请假节次：请在页面选择具体课程节次后再核对天数");
        if(dateList.length&&pageState.dayCountOk)done.push(`日历已选择${pageState.days}天；必填请假天数已设为${pageState.daysValue}天`);
        else if(dateList.length)skipped.push(`请假天数未确认：日期${pageState.days}天，页面字段显示${pageState.daysValue}`);
        else skipped.push("请假日期未识别；未清空日历，无法根据日期推算必填天数");
      }
      if(d.startPart||d.endPart)skipped.push(`上午/下午时段：页面“按天”日历只存日期，本版没有对应时段控件（识别到 ${d.startPart||""} 至 ${d.endPart||""}）`);
      const fileResult=await uploadProofFiles(d.files||[]);
      if(fileResult.uploaded.length)done.push("证明材料："+fileResult.uploaded.join("、"));
      if(fileResult.errors.length)skipped.push("证明材料自动上传未完成："+fileResult.errors.join("；"));
      else if(!(d.files||[]).length)skipped.push(d.hasAttachment?.startsWith("对话提到")?"证明材料：对话只提及病历，没有可读取的文件；请手动上传病历":"证明材料：请根据页面要求手动上传附件");
      return {ok:true,done,skipped,uploadErrors:fileResult.errors};
  }
  async function uploadProofFiles(files){
    const candidates=(Array.isArray(files)?files:[]).filter(item=>item&&typeof item.url==="string"&&/^https:\/\//i.test(item.url)).slice(0,5);
    if(!candidates.length)return {uploaded:[],errors:[]};
    const loaded=[],errors=[];
    for(const item of candidates){
      try{
        const response=await chrome.runtime.sendMessage({
          type:"LEAVE_FETCH_FILE",
          url:item.url,
          name:item.name||item.filename||"证明材料",
          mimeType:item.mimeType||item.mime_type||""
        }).catch(error=>({ok:false,error:error.message||String(error)}));
        if(!response?.ok)throw new Error(response?.error||"文件读取失败");
        const binary=atob(response.base64||"");
        const bytes=Uint8Array.from(binary,char=>char.charCodeAt(0));
        if(!bytes.length)throw new Error("文件内容为空");
        const safeName=String(response.name||item.name||"证明材料").replace(/[\\/:*?"<>|]/g,"_");
        loaded.push({name:safeName,mimeType:response.mimeType||"application/octet-stream",base64:response.base64});
      }catch(error){
        errors.push((item.name||"附件")+"："+(error.message||String(error)));
      }
    }
    if(!loaded.length)return {uploaded:[],errors};
    const result=await chrome.runtime.sendMessage({type:"LEAVE_SET_MAIN_FILES",files:loaded})
      .catch(error=>({ok:false,error:error.message||String(error)}));
    if(!result?.ok){
      errors.push(result?.error||"学校页面上传控件未接收文件");
      return {uploaded:[],errors};
    }
    if(!result.uiAcknowledged){
      errors.push("学校上传控件已接收文件，但页面未显示文件名或已上传状态");
      return {uploaded:[],errors};
    }
    return {uploaded:(result.selected||loaded.map(file=>file.name)),errors};
  }
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  async function waitForForm(timeout=30000){
    const until=Date.now()+timeout;
    while(Date.now()<until){
      const form=document.querySelector("#add-form-qjxx");
      if(form&&visible(form))return form;
      await wait(250);
    }
    return null;
  }
  async function waitForStartButton(timeout=30000){
    const until=Date.now()+timeout;
    while(Date.now()<until){
      const actions=[...document.querySelectorAll("[data-action],a,button,[role=button]")];
      const button=actions.find(el=>visible(el)&&norm(el.getAttribute("data-action")).includes("我要请假"))||
        actions.find(el=>visible(el)&&norm(el.innerText||el.textContent).includes("我要请假")&&norm(el.innerText||el.textContent).length<40);
      if(button)return button;
      await wait(300);
    }
    return null;
  }
  function announce(message){
    let box=document.getElementById("leave-assistant-status");
    if(!box){box=document.createElement("div");box.id="leave-assistant-status";Object.assign(box.style,{position:"fixed",zIndex:"2147483647",top:"12px",right:"12px",maxWidth:"440px",whiteSpace:"pre-wrap",padding:"12px 16px",borderRadius:"8px",boxShadow:"0 3px 16px #0003",background:"#f0f7ff",color:"#173b5b",font:"13px/1.55 system-ui,sans-serif"});document.documentElement.append(box);}
    const row=document.createElement("div");Object.assign(row.style,{display:"flex",alignItems:"flex-start",gap:"12px"});
    const text=document.createElement("div");text.textContent=message;Object.assign(text.style,{flex:"1",minWidth:"0"});
    const addFile=document.createElement("button");addFile.type="button";addFile.textContent="添加附件";addFile.setAttribute("aria-label","选择请假证明附件");
    Object.assign(addFile.style,{flex:"none",border:"1px solid #9cb5cc",borderRadius:"5px",background:"white",color:"#173b5b",padding:"3px 8px",cursor:"pointer",font:"12px system-ui,sans-serif"});
    addFile.addEventListener("click",()=>{
      const input=document.querySelector('#add-form-qjxx [data-field="ZMCL"] input[type="file"], #add-form-qjxx input[type="file"][name="bhFile"]');
      if(!input){text.textContent+="\n没有找到证明材料上传控件，请确认已打开请假申请表单。";return;}
      input.click();
    });
    const close=document.createElement("button");close.type="button";close.textContent="关闭";close.setAttribute("aria-label","关闭请假助手提示");
    Object.assign(close.style,{flex:"none",border:"1px solid #9cb5cc",borderRadius:"5px",background:"white",color:"#173b5b",padding:"3px 8px",cursor:"pointer",font:"12px system-ui,sans-serif"});
    close.addEventListener("click",()=>box.remove());row.append(text,addFile,close);box.replaceChildren(row);
  }
  async function launchAndFill(data){
    try{
      let form=await waitForForm(800);
      if(!form){
        const start=await waitForStartButton();
        if(!start)throw new Error("等待30秒仍未找到“我要请假”入口。请确认已登录并进入学生请假应用。");
        const clicked=await chrome.runtime.sendMessage({type:"LEAVE_CLICK_START"}).catch(error=>({ok:false,error:error.message||String(error)}));
        if(!clicked?.ok)throw new Error(clicked?.error||"无法触发页面的“我要请假”动作。");
        form=await waitForForm();
      }
      if(!form)throw new Error("请假表单未能打开；请在页面确认是否有错误提示。");
      const result=await fillTask(data);
      if(result.skipped.length)console.info("学生请假助手未自动完成的字段：",result.skipped);
      if(result.uploadErrors?.length){
        announce(`请假信息已填入，但证明材料未自动上传：\n- ${result.uploadErrors.join("\n- ")}\n\n请在页面中手动选择证明材料后再提交。`);
      }
      await chrome.runtime.sendMessage({type:"LEAVE_CLEAR_PENDING"}).catch(()=>{});
    }catch(e){announce(`未能自动填写：${e.message||String(e)}\n草稿已保留在扩展会话中；可重新打开扩展再试。`);}
  }
  chrome.runtime.onMessage.addListener((message,_sender,reply)=>{
    if(message?.type!=="LEAVE_FILL")return;
    fillTask(message.data||{}).then(reply).catch(e=>reply({ok:false,error:e.message||String(e)}));
    return true;
  });
  const directData=decodeDirectPrefill();
  if(directData){
    window.__leaveAssistantAutoStarted=true;
    clearDirectPrefill();
    const begin=()=>launchAndFill(directData);
    if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",begin,{once:true});
    else begin();
  }else if(location.hostname==="ehall.hainanu.edu.cn"&&location.pathname.startsWith("/xsfw/sys/xsqjapp/")&&!window.__leaveAssistantAutoStarted){
    window.__leaveAssistantAutoStarted=true;
    chrome.runtime.sendMessage({type:"LEAVE_GET_PENDING"}).then(result=>{if(result?.data)launchAndFill(result.data);}).catch(()=>{});
  }
})();
