import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
vm.runInThisContext(fs.readFileSync(path.join(root, "shared", "service-registry.js"), "utf8"));
vm.runInThisContext(fs.readFileSync(path.join(root, "shared", "prefill.js"), "utf8"));

test("research_paper_registration is registered", () => {
  const service = globalThis.HaiAgentServices.get("research_paper_registration");
  assert.equal(service.id, "research_paper_registration");
  assert.match(service.targetUrl, /kyxt\.hainanu\.edu\.cn/);
  assert.equal(service.adapter, "research");
});

test("Dify research prefill link routes to the research adapter", () => {
  const link = fs
    .readFileSync(path.join(root, "..", "sample_research_paper_prefill_link_0.4.0.txt"), "utf8")
    .trim();
  const parsed = globalThis.HaiAgentPrefill.parseUrl(link);
  assert.equal(parsed.serviceId, "research_paper_registration");
  assert.equal(parsed.data.title, "面向校园智能服务的大模型应用研究");
  assert.match(parsed.data.journal, /示例学报/);
  assert.equal(parsed.data.stopBeforeSubmit, true);
});
