import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
vm.runInThisContext(fs.readFileSync(path.join(root, "shared", "service-registry.js"), "utf8"));
vm.runInThisContext(fs.readFileSync(path.join(root, "shared", "prefill.js"), "utf8"));

const token = (value) => Buffer.from(JSON.stringify(value), "utf8").toString("base64url");

test("legacy leavePrefill remains supported", () => {
  const payload = {
    v: 1,
    leaveType: "事假",
    leaveMode: "按天",
    startDate: "2026-10-28",
    endDate: "2026-10-29",
    reason: "办理个人事务",
    expiresAt: "2099-01-01T00:00:00Z"
  };
  const parsed = globalThis.HaiAgentPrefill.parseUrl(
    `https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/*default/index.do#/wdqj?leavePrefill=${token(payload)}`
  );
  assert.equal(parsed.serviceId, "student_leave");
});

test("research paper registry and sample link align", () => {
  assert.match(
    globalThis.HaiAgentServices.getTargetUrl("research_paper_registration"),
    /kyxt\.hainanu\.edu\.cn/
  );
  const link = fs
    .readFileSync(path.join(root, "..", "sample_research_paper_prefill_link_0.4.0.txt"), "utf8")
    .trim();
  const parsed = globalThis.HaiAgentPrefill.parseUrl(link);
  assert.equal(parsed.serviceId, "research_paper_registration");
  assert.equal(parsed.data.paperName, "面向校园智能服务的大模型应用研究");
  assert.equal(parsed.data.modeId, "1");
  assert.equal(parsed.data.publishRangeId, "2");
  assert.deepEqual(parsed.data.embodyTypeIds, ["SCI"]);
  assert.equal(parsed.data.sciPartitionId, "1");
  assert.equal(parsed.autoAdvance, true);
});
