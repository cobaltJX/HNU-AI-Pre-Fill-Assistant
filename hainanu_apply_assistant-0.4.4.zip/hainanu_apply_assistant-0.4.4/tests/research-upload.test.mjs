import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const workerSource = fs.readFileSync(path.join(root, "worker.js"), "utf8");

test("research attachments upload once and skip the same file on retry", async () => {
  let messageListener;
  let changeEvents = 0;
  let inputEvents = 0;
  let buttonClicks = 0;
  let fieldText = "";
  const sessionValues = new Map();
  const inputs = [];

  class FakeFile {
    constructor(parts, name, options = {}) {
      this.name = name;
      this.size = parts[0]?.length || 0;
      this.type = options.type || "application/octet-stream";
    }
  }

  class FakeDataTransfer {
    constructor() {
      this.files = [];
      this.items = {
        add: (file) => {
          this.files.push(file);
        }
      };
    }
  }

  class FakeEvent {
    constructor(type, options = {}) {
      this.type = type;
      this.bubbles = options.bubbles;
    }
  }

  const field = {
    innerText: "",
    textContent: "",
    parentElement: null,
    matches(selector) {
      return selector === ".form-group";
    },
    querySelector(selector) {
      return selector.includes('input[type="file"]') ? inputs[0] || null : null;
    }
  };
  const button = {
    parentElement: field,
    scrollIntoView() {},
    closest(selector) {
      return selector === ".form-group" ? field : null;
    },
    click() {
      buttonClicks += 1;
    }
  };
  const input = {
    files: null,
    listeners: new Map(),
    addEventListener(type, listener) {
      this.listeners.set(type, listener);
    },
    dispatchEvent(event) {
      if (event.type === "change") changeEvents += 1;
      if (event.type === "input") inputEvents += 1;
      this.listeners.get(event.type)?.(event);
      return true;
    },
    closest() {
      return field;
    }
  };
  inputs.push(input);

  const document = {
    querySelector(selector) {
      return selector.includes('button[name=') ? button : null;
    },
    querySelectorAll(selector) {
      return selector.includes('input[type="file"]') ? inputs : [];
    }
  };

  const context = vm.createContext({
    chrome: {
      runtime: {
        id: "test-extension",
        onMessage: {
          addListener(listener) {
            messageListener = listener;
          }
        }
      },
      tabs: {
        onUpdated: { addListener() {} }
      },
      storage: {
        session: {
          async get(key) {
            return { [key]: sessionValues.get(key) };
          },
          async set(values) {
            for (const [key, value] of Object.entries(values)) sessionValues.set(key, value);
          },
          async remove(key) {
            sessionValues.delete(key);
          }
        }
      },
      scripting: {
        async executeScript({ func, args }) {
          const run = vm.runInContext(`(${func.toString()})`, context);
          return [{ result: await run(...args) }];
        }
      }
    },
    importScripts() {},
    URL,
    console,
    setTimeout,
    clearTimeout,
    document,
    CSS: { escape: (value) => value },
    Event: FakeEvent,
    File: FakeFile,
    DataTransfer: FakeDataTransfer,
    Uint8Array,
    atob: (value) => Buffer.from(value, "base64").toString("binary"),
    getComputedStyle: () => ({ visibility: "visible" }),
    sessionStorage: {
      getItem(key) {
        return sessionValues.has(key) ? sessionValues.get(key) : null;
      },
      setItem(key, value) {
        sessionValues.set(key, String(value));
      },
      removeItem(key) {
        sessionValues.delete(key);
      }
    }
  });
  vm.runInContext(workerSource, context);

  input.listeners.set("change", () => {
    field.innerText = input.files?.[0]?.name || "";
    field.textContent = field.innerText;
  });

  const dispatch = (message) =>
    new Promise((resolve) => {
      assert.equal(
        messageListener(
          message,
          {
            tab: {
              id: 7,
              url: "https://kyxt.hainanu.edu.cn/business/paperAction!to_add.action"
            }
          },
          resolve
        ),
        true
      );
    });
  const message = {
    type: "APPLY_SET_RESEARCH_FILES",
    field: {
      buttonName: "entity.fileIds_upload",
      inputName: "entity.fileIds",
      mode: "multiple",
      taskId: "task-1"
    },
    files: [
      {
        name: "测试论文.pdf",
        mimeType: "application/pdf",
        base64: Buffer.from("%PDF-test").toString("base64")
      }
    ]
  };

  const first = await dispatch(message);
  assert.equal(first.ok, true, JSON.stringify(first));
  assert.deepEqual(Array.from(first.uploaded), ["测试论文.pdf"]);
  assert.deepEqual(Array.from(first.alreadyUploaded), []);
  assert.equal(changeEvents, 1);
  assert.equal(inputEvents, 0, "only the native change event should be emitted");

  const second = await dispatch(message);
  assert.equal(second.ok, true);
  assert.deepEqual(Array.from(second.alreadyUploaded), ["测试论文.pdf"]);
  assert.equal(changeEvents, 1, "a repeated upload must not trigger change again");
  assert.equal(inputEvents, 0);
  assert.equal(buttonClicks, 0);
});
