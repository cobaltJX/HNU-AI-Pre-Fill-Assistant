import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const source = fs.readFileSync(path.join(root, "research-filler.js"), "utf8");
const pendingTask = {
  serviceId: "research_paper_registration",
  data: {
    serviceId: "research_paper_registration",
    prefillTaskId: "task-review",
    title: "测试论文"
  }
};

const waitFor = async (predicate, timeout = 1000) => {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error("timed out waiting for extension state");
};

function createHarness(url, sessionValues, initialPending) {
  let pending = initialPending;
  let clearCount = 0;
  let stepThreeLookups = 0;
  const document = {
    readyState: "complete",
    addEventListener() {},
    querySelector(selector) {
      if (selector === "#fromSelect") stepThreeLookups += 1;
      return null;
    },
    querySelectorAll() {
      return [];
    },
    documentElement: {
      append() {}
    }
  };
  const context = vm.createContext({
    chrome: {
      runtime: {
        async sendMessage(message) {
          if (message?.type === "APPLY_GET_PENDING") return pending;
          if (message?.type === "APPLY_CLEAR_PENDING") {
            clearCount += 1;
            pending = null;
            return { ok: true };
          }
          if (message?.type === "APPLY_STORE_PENDING") {
            pending = {
              serviceId: message.serviceId,
              data: message.data,
              targetTabId: 9
            };
            return { ok: true };
          }
          return { ok: true };
        }
      }
    },
    URL,
    URLSearchParams,
    console,
    document,
    location: {
      href: url,
      hostname: "kyxt.hainanu.edu.cn",
      pathname: new URL(url).pathname
    },
    sessionStorage: {
      getItem(key) {
        return sessionValues.has(key) ? sessionValues.get(key) : null;
      },
      setItem(key, value) {
        sessionValues.set(key, String(value));
      },
      removeItem(key) {
        sessionValues.delete(key);
      }
    },
    crypto: {
      randomUUID() {
        return "new-task-id";
      }
    },
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval
  });
  vm.runInContext(source, context);
  return {
    get clearCount() {
      return clearCount;
    },
    get stepThreeLookups() {
      return stepThreeLookups;
    }
  };
}

test("returning from review does not run the pending task again", async () => {
  const sessionValues = new Map();
  const review = createHarness(
    "https://kyxt.hainanu.edu.cn/business/paperAction!to_finishStep.action",
    sessionValues,
    pendingTask
  );
  await waitFor(() => review.clearCount === 1);
  assert.equal(sessionValues.get("haiResearchReachedReview"), "1");

  const backToStepThree = createHarness(
    "https://kyxt.hainanu.edu.cn/business/paperAction!to_supportProjectAdd.action?curStepNum=3",
    sessionValues,
    pendingTask
  );
  await waitFor(() => backToStepThree.clearCount === 1);
  assert.equal(
    backToStepThree.stepThreeLookups,
    0,
    "step 3 must not be filled or auto-advanced after review was reached"
  );
});

test("version and upload deduplication safeguards are present", () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, "manifest.json"), "utf8"));
  const worker = fs.readFileSync(path.join(root, "worker.js"), "utf8");
  assert.equal(manifest.version, "0.4.4");
  assert.match(source, /REVIEW_REACHED_KEY/);
  assert.match(source, /await clearPendingTask\(\)/);
  assert.match(source, /if \(reviewReached\(\)\) return/);
  assert.match(worker, /alreadyUploaded/);
  assert.match(worker, /__haiResearchUpload:/);
  const researchUploadBlock = worker.slice(
    worker.indexOf('if(message?.type==="APPLY_SET_RESEARCH_FILES")'),
    worker.indexOf('if(message?.type==="APPLY_STORE_PENDING")')
  );
  assert.doesNotMatch(
    researchUploadBlock,
    /input\.dispatchEvent\(new Event\("input",\{bubbles:true\}\)\);\s*input\.dispatchEvent\(new Event\("change"/
  );
});
