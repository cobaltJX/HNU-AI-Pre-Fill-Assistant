(() => {
  const SERVICES = {
    student_leave: {
      id: "student_leave",
      label: "学生请假",
      targetUrl: "https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/*default/index.do#/wdqj",
      pagePrefix: "https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/",
      adapter: "leave"
    },
    research_paper_registration: {
      id: "research_paper_registration",
      label: "科研论文登记",
      targetUrl: "https://kyxt.hainanu.edu.cn/userAction!do_casLogin.action?servAppId=2c92bcb167c916610167c91960700004",
      pagePrefix: "https://kyxt.hainanu.edu.cn/",
      adapter: "research"
    }
  };

  const normalize = (id) => String(id || "student_leave").trim() || "student_leave";

  globalThis.HaiAgentServices = {
    services: SERVICES,
    list() {
      return Object.values(SERVICES);
    },
    get(id) {
      return SERVICES[normalize(id)] || null;
    },
    getTargetUrl(id) {
      const service = this.get(id);
      if (!service?.targetUrl) throw new Error(`未注册可打开的办事事项：${normalize(id)}`);
      return service.targetUrl;
    },
    isAllowedPage(id, url) {
      const service = this.get(id);
      return !!service?.pagePrefix && String(url || "").startsWith(service.pagePrefix);
    }
  };
})();
