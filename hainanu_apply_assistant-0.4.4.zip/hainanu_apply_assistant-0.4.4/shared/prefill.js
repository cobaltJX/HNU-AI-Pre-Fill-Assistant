(() => {
  const DEFAULT_SERVICE_ID = "student_leave";

  const decodeJson = (token) => {
    if (!token) return null;
    try {
      if (token.startsWith("%7B") || token.startsWith("{")) {
        return JSON.parse(decodeURIComponent(token));
      }
      const b64 = token.replace(/-/g, "+").replace(/_/g, "/");
      const padded = b64.padEnd(Math.ceil(b64.length / 4) * 4, "=");
      const binary = atob(padded);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      return JSON.parse(new TextDecoder().decode(bytes));
    } catch {
      return null;
    }
  };

  const parseFileList = (token) => {
    const value = decodeJson(token);
    return Array.isArray(value)
      ? value.filter((item) => item && typeof item.url === "string" && /^https:\/\//i.test(item.url))
      : [];
  };

  const parseParams = (url) => {
    const parsed = new URL(url, typeof location !== "undefined" ? location.href : undefined);
    const hash = parsed.hash.replace(/^#/, "");
    const hashQuery = hash.includes("?") ? hash.slice(hash.indexOf("?") + 1) : "";
    const bareHashParams = new URLSearchParams(hash.startsWith("?") ? hash.slice(1) : hash);
    const hashParams = hash.includes("?") ? new URLSearchParams(hashQuery) : bareHashParams;
    const query = new URLSearchParams(parsed.search);
    const token =
      query.get("leavePrefill") ||
      query.get("applyPrefill") ||
      hashParams.get("leavePrefill") ||
      hashParams.get("applyPrefill") ||
      "";
    const filesToken = query.get("leaveFiles") || hashParams.get("leaveFiles") || "";
    return { parsed, token, filesToken };
  };

  const normalize = (payload) => {
    if (!payload || typeof payload !== "object") return null;
    const version = payload.version || payload.v;
    if (version === "apply-prefill.v1") {
      if (!payload.serviceId || !payload.data || typeof payload.data !== "object") return null;
      return {
        serviceId: String(payload.serviceId),
        data: { ...payload.data },
        files: Array.isArray(payload.files) ? payload.files : [],
        autoAdvance:
          payload.autoAdvance ??
          payload.auto_advance ??
          payload.workflow?.autoAdvance ??
          payload.data.autoAdvance ??
          payload.data.auto_advance,
        stopBeforeSubmit:
          payload.stopBeforeSubmit ??
          payload.workflow?.stopBeforeSubmit ??
          payload.data.stopBeforeSubmit,
        expiresAt: payload.expiresAt || ""
      };
    }
    if (version === 1 && payload.leaveType) {
      return {
        serviceId: DEFAULT_SERVICE_ID,
        data: { ...payload },
        files: Array.isArray(payload.files) ? payload.files : [],
        expiresAt: payload.expiresAt || ""
      };
    }
    if (payload.data && typeof payload.data === "object") {
      return {
        serviceId: payload.serviceId || DEFAULT_SERVICE_ID,
        data: { ...payload.data },
        files: Array.isArray(payload.files) ? payload.files : [],
        expiresAt: payload.expiresAt || ""
      };
    }
    return null;
  };

  const parseUrl = (url) => {
    try {
      const { token, filesToken } = parseParams(String(url || ""));
      if (!token) return null;
      const payload = decodeJson(token);
      const result = normalize(payload);
      if (!result) return null;
      if (result.expiresAt && Date.now() > Date.parse(result.expiresAt)) return null;
      const linkFiles = parseFileList(filesToken);
      if (linkFiles.length) result.files = linkFiles;
      if (Array.isArray(result.data.files) && result.data.files.length) {
        result.files = result.data.files;
      }
      // Keep the legacy leave task as the same object shape consumed by
      // leave-filler.js. The adapter boundary is added without changing it.
      result.data.files = result.files;
      return result;
    } catch {
      return null;
    }
  };

  globalThis.HaiAgentPrefill = {
    version: "apply-prefill.v1",
    decodeJson,
    parseFileList,
    normalize,
    parseUrl
  };
})();
