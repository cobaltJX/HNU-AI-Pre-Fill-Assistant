const $ = id => document.getElementById(id);
const status = (s, error=false) => { $("status").textContent=s; $("status").style.color=error?"#a52828":"#38536d"; };
let current = null;

function extract(text) {
  const t=String(text||"").replace(/\u00a0/g," ");
  const normalized=t.replace(/[\t ]+/g," ");
  const dateRe=/(20\d{2})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})\s*日?/g;
  const dates=[...normalized.matchAll(dateRe)].map(m=>({year:+m[1],month:+m[2],day:+m[3],at:m.index}));
  const cnRe=/(\d{1,2})\s*月\s*(\d{1,2})\s*日?/g;
  for(const m of normalized.matchAll(cnRe)) dates.push({year:null,month:+m[1],day:+m[2],at:m.index});
  dates.sort((a,b)=>a.at-b.at);
  const unique=dates.filter((d,i,a)=>!a.slice(0,i).some(x=>x.month===d.month&&x.day===d.day));
  const year=unique.find(d=>d.year)?.year || new Date().getFullYear();
  const fmt=(d)=>d?`${d.year||year}-${String(d.month).padStart(2,"0")}-${String(d.day).padStart(2,"0")}`:"";
  const period=[...normalized.matchAll(/(?:请假时间|请假日期|时间)\s*[：:]?\s*([^\n。]{5,100})/g)].map(m=>m[1]).find(s=>/(至|到|—|—|~|～)/.test(s));
  const span=period ? [...period.matchAll(/(?:20\d{2}\s*[-/.年]\s*)?\d{1,2}\s*(?:[-/.月])\s*\d{1,2}\s*日?/g)] : [];
  let start=unique[0], end=unique[1]||unique[0];
  if(span.length>=2){
    const pdates=span.map(m=>{const raw=m[0], z=raw.match(/(20\d{2})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})/);const c=raw.match(/(\d{1,2})\s*[-/.月]\s*(\d{1,2})/);return z?{year:+z[1],month:+z[2],day:+z[3]}:{year:null,month:+c[1],day:+c[2]};});
    [start,end]=pdates;
  }
  const explicit=(label)=>{
    const re=new RegExp(`${label}\\s*[：:]\\s*([^\\n。]+)`);
    return normalized.match(re)?.[1]?.trim()||"";
  };
  let reason=explicit("请假事由");
  if(!reason){
    const m=normalized.match(/(?:我|本人)(?:要|需要|想)?\s*(?:去|到).{0,70}?(?:查看|检查|治疗|就诊|看病|办理|参加|处理).{0,50}/);
    if(m) reason=m[0].trim().replace(/[，,；;。\s]*(?:附件是|附件为|不外出|不出校|就在校.*)$/," ").trim();
  }
  if(!reason){const m=normalized.match(/(?:我要|需要)(.{2,80}?)(?:附件|不外出|不出校|就在校|目的地|时间从|请假时间)/);if(m)reason=m[1].trim().replace(/[，,。\s]+$/g,"");}
  const type=/病假|因病/.test(normalized)?"病假":(/事假/.test(normalized)?"事假":"");
  const phone=normalized.match(/(?:^|\D)(1[3-9]\d{9})(?!\d)/)?.[1]||"";
  const outside=/不外出|不出校|是否外出\s*[：:]\s*否|是否出校\s*[：:]\s*否/.test(normalized)?"否":(/外出|出校/.test(normalized)?"请核对":"");
  let destination=explicit("目的地");
  if(!destination && /校医院/.test(normalized)) destination="中国 / 海口 / 校医院";
  const periodText=period||normalized;
  const part=periodText.match(/上午|早上|中午|下午|晚上/g)||[];
  const leaveMode=/按节次|第\s*\d+\s*节|节次/.test(normalized)?"按节次":"按天";
  return {
    leaveType:type, leaveMode, startDate:fmt(start), startPart:part[0]||"", endDate:fmt(end), endPart:part[1]||part[0]||"",
    leaveDays:dateCount(fmt(start),fmt(end)),
    reason, phone, outside, destination,
    hasAttachment:/附件/.test(normalized)?"对话提到附件；未读取到附件文件":"未提到附件"
  };
}

const schema=[
  ["leaveType","请假类型"],["leaveMode","请假方式"],["startDate","开始日期"],["startPart","开始时段"],["endDate","结束日期"],["endPart","结束时段"],["leaveDays","按日期范围计算的天数"],
  ["reason","请假事由"],["phone","手机号（必填）"],["outside","是否外出/出校"],["destination","目的地"],["hasAttachment","附件状态"]
];
function render(data){
  current=data; $("preview").hidden=false; $("fields").replaceChildren();
  for(const [key,title] of schema){
    const wrap=document.createElement("div");wrap.className="field";
    const label=document.createElement("label");label.textContent=title;
    const input=document.createElement("input");input.value=data[key]||"";input.dataset.key=key;
    if(key==="leaveDays")input.readOnly=true;
    wrap.append(label,input);$("fields").append(wrap);
  }
}
function edited(){const d={...current};for(const el of $("fields").querySelectorAll("input"))d[el.dataset.key]=el.value.trim();d.leaveDays=dateCount(d.startDate,d.endDate);return d;}
function dateCount(start,end){
  const a=/^(\d{4})-(\d{2})-(\d{2})$/.exec(start||""),b=/^(\d{4})-(\d{2})-(\d{2})$/.exec(end||"");
  if(!a||!b)return "";
  const valid=m=>{const d=new Date(Date.UTC(+m[1],+m[2]-1,+m[3]));return d.getUTCFullYear()===+m[1]&&d.getUTCMonth()+1===+m[2]&&d.getUTCDate()===+m[3];};
  if(!valid(a)||!valid(b))return "";
  const from=Date.UTC(+a[1],+a[2]-1,+a[3]),to=Date.UTC(+b[1],+b[2]-1,+b[3]);
  return to<from?"":Math.floor((to-from)/86400000)+1;
}
$("fields").addEventListener("input",event=>{
  if(!["startDate","endDate"].includes(event.target?.dataset?.key))return;
  const start=$("fields").querySelector('[data-key="startDate"]')?.value;
  const end=$("fields").querySelector('[data-key="endDate"]')?.value;
  const days=$("fields").querySelector('[data-key="leaveDays"]');
  if(days)days.value=dateCount(start,end);
});
function run(id, fn){$(id).addEventListener("click",async()=>{try{$(id).disabled=true;await fn();}catch(e){status(e.message||String(e),true);}finally{$(id).disabled=false;}});}
$("sourceFile").addEventListener("change",async()=>{
  const file=$("sourceFile").files?.[0]; if(!file)return;
  try{
    if(file.size>5*1024*1024)throw new Error("文件过大，请选择5MB以内的对话文件。");
    let source=await file.text();
    if(/\.html?$/i.test(file.name)||/<html[\s>]/i.test(source)){
      const doc=new DOMParser().parseFromString(source,"text/html");
      doc.querySelectorAll("script,style,noscript,svg").forEach(el=>el.remove());
      source=(doc.querySelector("#chat-container")||doc.querySelector("main")||doc.body)?.innerText||"";
    }
    $("raw").value=source;render(extract(source));status(`已读取 ${file.name} 并提取文字。核对识别结果，文件只在本机扩展弹窗中处理。`);
  }catch(e){status(e.message||String(e),true);}
});
run("parse",async()=>{const result=extract($("raw").value);render(result);status("已识别。请逐项核实，缺失或错误的信息请手动修改。日期/时段是从对话推断的，请特别核对年份。取自附件的文件内容不在 test.html 中。");});
run("readChat",async()=>{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!tab.url?.startsWith("https://ai.hainanu.edu.cn/"))throw new Error("请先切换到小海请假对话，再读取。");
  const result=await chrome.tabs.sendMessage(tab.id,{type:"LEAVE_READ_CHAT"}).catch(()=>null);
  if(!result)throw new Error("连接不到小海对话页面。请重新加载扩展后刷新小海页面，再试一次。");
  if(!result?.ok)throw new Error(result?.error||"未能读取小海对话。");
  $("raw").value=result.text;render(extract(result.text));status("已读取对话并识别。核对信息后再填写。日期年份仍需人工确认。");
});
run("launchFromChat",async()=>{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!tab.url?.startsWith("https://ai.hainanu.edu.cn/"))throw new Error("请先切换到小海请假对话页面。");
  const response=await chrome.tabs.sendMessage(tab.id,{type:"LEAVE_LAUNCH_CONFIRMED"}).catch(()=>null);
  if(!response)throw new Error("连接不到小海对话脚本。请到扩展管理页重新加载扩展，再刷新小海页面。");
  if(!response.ok)throw new Error(response.error||"未能识别最终请假入口。");
  status("已识别，请假页面正在新标签页打开；原对话会保留。");
  await chrome.tabs.update(response.tabId,{active:true});
});
run("fill",async()=>{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||typeof tab.url!=="string")throw new Error("无法读取当前标签页。");
  const sourceOk=tab.url.startsWith("https://ai.hainanu.edu.cn/")||tab.url.startsWith("https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/");
  if(!sourceOk)throw new Error("请从小海对话页，或学生请假应用页启动此操作。");
  const data=edited();
  if(!data.leaveType||!data.reason)throw new Error("请先补全请假类型和请假事由。");
  const result=await chrome.runtime.sendMessage({type:"LEAVE_OPEN_NEW_TAB",serviceId:"student_leave",data});
  if(!result?.ok)throw new Error(result?.error||"未能新开请假页面。");
  await chrome.tabs.update(result.tabId,{active:true});
  status("已在新标签页打开学校请假页面；原对话页会保留。目标页将自动填写识别内容。");
});
chrome.storage.session.get("leaveAssistantPending").then(result=>{
  const pending=result.leaveAssistantPending?.data||result.leaveAssistantPending;
  if(!current&&pending){render(pending);status("检测到尚未完成的请假草稿。可再次点击“新开页面并自动填写”重试。");}
}).catch(()=>{});
