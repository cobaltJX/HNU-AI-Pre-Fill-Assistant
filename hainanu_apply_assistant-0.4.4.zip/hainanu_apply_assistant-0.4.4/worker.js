importScripts("shared/service-registry.js", "shared/prefill.js");

const redirectingPrefillTabs=new Set();

async function redirectPrefillTab(tabId,url){
  if(!tabId||!url||!globalThis.HaiAgentPrefill||!globalThis.HaiAgentServices)return false;
  if(!/#(?:apply|leave)Prefill=/.test(url)||redirectingPrefillTabs.has(tabId))return false;
  redirectingPrefillTabs.add(tabId);
  try{
    const normalized=globalThis.HaiAgentPrefill.parseUrl(url);
    if(!normalized?.data)return false;
    const serviceId=String(normalized.serviceId||"student_leave");
    const targetUrl=globalThis.HaiAgentServices.getTargetUrl(serviceId);
    const data={
      ...normalized.data,
      serviceId,
      files:Array.isArray(normalized.files)?normalized.files:[]
    };
    await chrome.storage.session.set({
      leaveAssistantPending:{data,serviceId,targetTabId:tabId,sourceUrl:url}
    });
    await chrome.tabs.update(tabId,{url:targetUrl,active:true});
    return true;
  }catch(error){
    console.warn("小海预填链接原地跳转失败：",error?.message||String(error));
    return false;
  }finally{
    setTimeout(()=>redirectingPrefillTabs.delete(tabId),3000);
  }
}

if(chrome.tabs?.onUpdated?.addListener){
  chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab)=>{
    const url=changeInfo?.url||tab?.url||"";
    if(!/#(?:apply|leave)Prefill=/.test(url))return;
    redirectPrefillTab(tabId,url).catch(()=>{});
  });
}

chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message?.type==="APPLY_FETCH_FILE"){
    (async()=>{
      const senderUrl=String(sender.tab?.url||"");
      if(!senderUrl.startsWith("https://kyxt.hainanu.edu.cn/")&&!senderUrl.startsWith("https://ai.hainanu.edu.cn/"))
        throw new Error("只允许为科研论文登记页面读取小海附件。");
      const url=new URL(String(message.url||""));
      if(url.protocol!=="https:"||url.hostname!=="ai.hainanu.edu.cn"||
        !(/^\/(?:dify\/)?files\//.test(url.pathname)||/^\/api\/v1\/files\//.test(url.pathname)||
          url.pathname==="/haiagent/api/v1/hainanu/prefill/file"||
          url.pathname==="/haiagent/api/v1/hainanu/leave/file"))
        throw new Error("附件地址不受信任。");
      const response=await fetch(url.href,{credentials:"include",cache:"no-store",redirect:"follow"});
      if(!response.ok)throw new Error(`附件下载失败（HTTP ${response.status}）。`);
      const declaredSize=Number(response.headers.get("content-length")||0);
      if(declaredSize>40*1024*1024)throw new Error("单个附件超过40MB，未自动上传。");
      const bytes=new Uint8Array(await response.arrayBuffer());
      if(bytes.length>40*1024*1024)throw new Error("单个附件超过40MB，未自动上传。");
      let binary="";
      for(let offset=0;offset<bytes.length;offset+=0x8000){
        binary+=String.fromCharCode(...bytes.subarray(offset,Math.min(offset+0x8000,bytes.length)));
      }
      reply({
        ok:true,
        name:String(message.name||"附件"),
        mimeType:String(message.mimeType||response.headers.get("content-type")||"application/octet-stream").split(";")[0],
        size:bytes.length,
        base64:btoa(binary)
      });
    })().catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if(message?.type==="APPLY_SET_RESEARCH_FILES"){
    (async()=>{
      const tabId=sender.tab?.id,pageUrl=sender.tab?.url;
      if(!tabId||!pageUrl?.startsWith("https://kyxt.hainanu.edu.cn/"))
        throw new Error("只能在科研论文登记页面写入附件。");
      const field=message.field&&typeof message.field==="object"?message.field:{};
      if(!field.buttonName||!field.inputName)throw new Error("附件字段配置无效。");
      const files=(Array.isArray(message.files)?message.files:[]).slice(0,10).filter(file=>
        file&&typeof file.name==="string"&&typeof file.base64==="string"&&file.base64.length<56*1024*1024
      );
      if(!files.length)throw new Error("没有可写入的附件。");
      const results=await chrome.scripting.executeScript({
        target:{tabId},
        world:"MAIN",
        func:async(config,incoming)=>{
          const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
          const visible=element=>!!element&&!!element.getClientRects().length&&getComputedStyle(element).visibility!=="hidden";
          const decodeBase64=value=>{
            const binary=atob(value||"");
            return Uint8Array.from(binary,char=>char.charCodeAt(0));
          };
          const button=document.querySelector(`button[name="${CSS.escape(config.buttonName)}"]`);
          if(!button)return {ok:false,error:"科研系统附件上传按钮未找到。"};
          try{button.scrollIntoView({block:"center",behavior:"instant"});}catch{}
          const inputSelector=`input[type="file"][name="${CSS.escape(config.inputName)}"]`;
          const fieldTextOf=element=>String(element?.innerText||element?.textContent||"")
            .replace(/\s+/g," ").trim();
          const findFieldScope=()=>{
            let current=button.parentElement;
            for(let depth=0;current&&depth<6;depth++,current=current.parentElement){
              if(current.matches?.(".form-group"))return current;
              if(current.querySelector?.(inputSelector))return current;
            }
            return button.closest(".form-group")||button.parentElement||button;
          };
          let fieldScope=findFieldScope();
          const currentInputs=()=>[...document.querySelectorAll(inputSelector)];
          const findEmptyInput=()=>currentInputs().reverse().find(input=>!input.files?.length);
          const baseName=value=>String(value||"").split(/[\\/]/).pop()||"";
          const safeFileName=value=>baseName(value||"附件").replace(/[\\/:*?"<>|]/g,"_");
          const nameKey=value=>String(value||"").normalize("NFKC").toLowerCase()
            .replace(/[\s\u00a0_.\-—–()（）【】\[\]]/g,"");
          const fileKeys=value=>{
            const name=baseName(value);
            const stem=name.replace(/\.[^.]+$/,"");
            return [...new Set([nameKey(name),nameKey(stem)])].filter(key=>key.length>=4);
          };
          const namesMatch=(left,right)=>{
            const a=fileKeys(left),b=fileKeys(right);
            return a.some(key=>b.includes(key));
          };
          const uploadHistoryKey=config.taskId
            ?`__haiResearchUpload:${String(config.taskId)}:${config.inputName}`
            :"";
          const readUploadHistory=()=>{
            if(!uploadHistoryKey)return [];
            try{
              const value=JSON.parse(sessionStorage.getItem(uploadHistoryKey)||"[]");
              return Array.isArray(value)?value.filter(item=>typeof item==="string"):[];
            }catch{
              return [];
            }
          };
          const rememberUpload=name=>{
            if(!uploadHistoryKey)return;
            const history=readUploadHistory();
            if(history.some(item=>namesMatch(item,name)))return;
            try{sessionStorage.setItem(uploadHistoryKey,JSON.stringify([...history,name]));}catch{}
          };
          const alreadyPresent=name=>{
            if(readUploadHistory().some(item=>namesMatch(item,name)))return true;
            if(currentInputs().some(input=>[...(input.files||[])].some(file=>namesMatch(file.name,name))))return true;
            fieldScope=findFieldScope();
            const textKey=nameKey(fieldTextOf(fieldScope));
            return fileKeys(name).some(key=>textKey.includes(key));
          };
          const uploaded=[],alreadyUploaded=[],errors=[];
          for(const item of incoming){
            const safeName=safeFileName(item.name);
            if(alreadyPresent(safeName)){
              uploaded.push(safeName);
              alreadyUploaded.push(safeName);
              continue;
            }
            let input=findEmptyInput();
            if(!input){
              button.click();
              for(let attempt=0;attempt<30;attempt++){
                input=findEmptyInput();
                if(input)break;
                await wait(100);
              }
            }
            if(!input){
              errors.push(`${item.name}：页面未创建文件控件`);
              continue;
            }
            try{
              const bytes=decodeBase64(item.base64);
              if(!bytes.length)throw new Error("文件内容为空");
              const file=new File([bytes],safeName,{type:item.mimeType||"application/octet-stream"});
              const transfer=new DataTransfer();
              transfer.items.add(file);
              input.files=transfer.files;
              input.dispatchEvent(new Event("change",{bubbles:true}));
              await wait(500);
              if(input.files?.length!==1)throw new Error("上传控件未保留文件");
              uploaded.push(safeName);
              rememberUpload(safeName);
            }catch(error){
              errors.push(`${item.name||"附件"}：${error?.message||String(error)}`);
            }
          }
          fieldScope=findFieldScope();
          const fieldText=fieldTextOf(fieldScope).slice(0,2000);
          return {
            ok:uploaded.length>0,
            uploaded,
            alreadyUploaded,
            errors,
            fieldText,
            inputCount:currentInputs().length
          };
        },
        args:[{
          buttonName:String(field.buttonName),
          inputName:String(field.inputName),
          mode:String(field.mode||"multiple"),
          taskId:String(field.taskId||"")
        },files]
      });
      reply(results?.[0]?.result||{ok:false,error:"没有收到科研附件上传结果。"});
    })().catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if(message?.type==="APPLY_STORE_PENDING"){
    (async()=>{
      const tabId=sender.tab?.id,pageUrl=sender.tab?.url;
      if(!tabId||(!pageUrl?.startsWith("https://kyxt.hainanu.edu.cn/")&&
        !pageUrl?.startsWith("https://ai.hainanu.edu.cn/")))
        throw new Error("只允许保存科研论文登记任务。");
      const serviceId=String(message.serviceId||message.data?.serviceId||"");
      if(serviceId!=="research_paper_registration")throw new Error("不支持的科研办事事项。");
      const pending={data:{...message.data,serviceId},serviceId,targetTabId:tabId};
      await chrome.storage.session.set({leaveAssistantPending:pending});
      reply({ok:true});
    })().catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if(message?.type==="LEAVE_FETCH_FILE"){
    (async()=>{
      if(!sender.tab?.url?.startsWith("https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/"))
        throw new Error("只允许在海南大学学生请假页面读取证明材料。");
      const url=new URL(String(message.url||""));
      if(url.protocol!=="https:"||url.hostname!=="ai.hainanu.edu.cn"||
        !(/^\/(?:dify\/)?files\//.test(url.pathname)||/^\/api\/v1\/files\//.test(url.pathname)||
          url.pathname==="/haiagent/api/v1/hainanu/leave/file"||
          url.pathname==="/haiagent/api/v1/hainanu/prefill/file"))
        throw new Error("证明材料地址不受信任。");
      const response=await fetch(url.href,{credentials:"include",cache:"no-store",redirect:"follow"});
      if(!response.ok)throw new Error(`证明材料下载失败（HTTP ${response.status}）。`);
      const declaredSize=Number(response.headers.get("content-length")||0);
      if(declaredSize>20*1024*1024)throw new Error("证明材料超过20MB，未自动上传。");
      const bytes=new Uint8Array(await response.arrayBuffer());
      if(bytes.length>20*1024*1024)throw new Error("证明材料超过20MB，未自动上传。");
      let binary="";
      for(let offset=0;offset<bytes.length;offset+=0x8000){
        binary+=String.fromCharCode(...bytes.subarray(offset,Math.min(offset+0x8000,bytes.length)));
      }
      reply({
        ok:true,
        name:String(message.name||"证明材料"),
        mimeType:String(message.mimeType||response.headers.get("content-type")||"application/octet-stream").split(";")[0],
        size:bytes.length,
        base64:btoa(binary)
      });
    })().catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if(message?.type==="LEAVE_SET_MAIN_FILES"){
    (async()=>{
      const tabId=sender.tab?.id,pageUrl=sender.tab?.url;
      if(!tabId||!pageUrl?.startsWith("https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/"))
        throw new Error("只能在学校请假页面写入证明材料。");
      const files=(Array.isArray(message.files)?message.files:[]).slice(0,5).filter(file=>
        file&&typeof file.name==="string"&&typeof file.base64==="string"&&file.base64.length<28*1024*1024
      );
      if(!files.length)throw new Error("没有可写入的证明材料。");
      const results=await chrome.scripting.executeScript({
        target:{tabId},
        world:"MAIN",
        func:async(incoming)=>{
          const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
          const decodeBase64=value=>{
            const binary=atob(value||"");
            return Uint8Array.from(binary,char=>char.charCodeAt(0));
          };
          let form=document.querySelector("#add-form-qjxx");
          if(!form)return {ok:false,error:"请假表单尚未打开。"};
          let field=form.querySelector('[data-field="ZMCL"]')||form;
          let inputs=[];
          for(let attempt=0;attempt<40;attempt++){
            field=form.querySelector('[data-field="ZMCL"]')||form;
            inputs=[...new Set([...field.querySelectorAll('input[type="file"]'),...form.querySelectorAll('input[type="file"]')])];
            if(inputs.length)break;
            await wait(200);
          }
          const describe=input=>({
            name:input.getAttribute("name")||"",
            id:input.id||"",
            className:typeof input.className==="string"?input.className:"",
            accept:input.getAttribute("accept")||"",
            multiple:!!input.multiple,
            inMaterialField:field!==form&&field.contains(input)
          });
          const score=input=>{
            let value=0;
            if(field!==form&&field.contains(input))value+=100;
            if((input.getAttribute("name")||"").toLowerCase()==="bhfile")value+=30;
            if(input.accept)value+=5;
            if(!input.disabled)value+=2;
            if(input.multiple)value+=1;
            return value;
          };
          const input=inputs.sort((a,b)=>score(b)-score(a))[0];
          if(!input)return {
            ok:false,
            error:"没有找到学校证明材料上传控件。",
            diagnostics:{inputs:[],fieldText:String(field.innerText||"").trim().slice(0,500)}
          };
          try{field.scrollIntoView({block:"center",behavior:"instant"});}catch{}
          const loaded=incoming.map(item=>{
            const bytes=decodeBase64(item.base64);
            const safeName=String(item.name||"证明材料").replace(/[\\/:*?"<>|]/g,"_");
            return new File([bytes],safeName,{type:item.mimeType||"application/octet-stream"});
          });
          const selected=input.multiple?loaded:loaded.slice(0,1);
          const transfer=new DataTransfer();
          selected.forEach(file=>transfer.items.add(file));
          let inputReady=false,error="";
          try{
            input.files=transfer.files;
            input.dispatchEvent(new Event("input",{bubbles:true}));
            input.dispatchEvent(new Event("change",{bubbles:true}));
            inputReady=input.files?.length===selected.length;
          }catch(exception){
            error=exception?.message||String(exception);
          }
          const jq=window.jQuery||window.$;
          let jqueryTriggered=false,fileuploadAdded=false;
          if(typeof jq==="function"){
            try{jq(input).trigger("input");jq(input).trigger("change");jqueryTriggered=true;}catch{}
            try{
              if(typeof jq.fn?.fileupload==="function"){
                jq(input).fileupload("add",{files:Array.from(transfer.files)});
                fileuploadAdded=true;
              }
            }catch{}
          }
          const zones=[field,field.parentElement,input.closest('[class*="upload"],[class*="file"],[data-field="ZMCL"]'),...field.querySelectorAll('[class*="upload"],[class*="file"]')]
            .filter((zone,index,list)=>zone&&list.indexOf(zone)===index);
          let drops=0;
          for(const zone of zones){
            for(const type of ["dragenter","dragover","drop"]){
              try{
                zone.dispatchEvent(new DragEvent(type,{bubbles:true,cancelable:true,dataTransfer:transfer}));
                drops++;
              }catch{}
            }
          }
          let fieldText="",formValue="";
          for(let attempt=0;attempt<12;attempt++){
            await wait(300);
            fieldText=zones.map(zone=>String(zone.innerText||zone.textContent||"").trim()).filter(Boolean).join("\n").slice(0,4000);
            try{
              const value=form.emapForm?.("getValue")?.ZMCL;
              formValue=value===undefined||value===null?"":String(value);
            }catch{}
            const namesVisible=selected.some(file=>fieldText.includes(file.name.replace(/\.[^.]+$/,"")));
            if(namesVisible||/上传成功|已上传/.test(fieldText))break;
          }
          const namesVisible=selected.some(file=>fieldText.includes(file.name.replace(/\.[^.]+$/,"")));
          const uiAcknowledged=namesVisible||/上传成功|已上传/.test(fieldText)||!!formValue;
          return {
            ok:inputReady,
            inputReady,
            uiAcknowledged,
            error,
            method:{jqueryTriggered,fileuploadAdded,drops},
            selected:selected.map(file=>file.name),
            input:describe(input),
            fieldText:fieldText.slice(0,1000),
            formValue:formValue.slice(0,1000),
            diagnostics:{inputs:inputs.map(describe)}
          };
        },
        args:[files]
      });
      reply(results?.[0]?.result||{ok:false,error:"没有收到学校上传控件结果。"});
    })().catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if(message?.type==="LEAVE_OPEN_NEW_TAB"||message?.type==="APPLY_OPEN_NEW_TAB"){
    (async()=>{
      const fromPopup=sender.url?.startsWith(`chrome-extension://${chrome.runtime.id}/`);
      const fromChat=sender.tab?.url?.startsWith("https://ai.hainanu.edu.cn/");
      if(!fromPopup&&!fromChat)throw new Error("只接受小海对话页或扩展弹窗发起的请假任务。");
      if(message.autoKey){
        const saved=await chrome.storage.session.get("leaveAssistantLastAutoKey");
        if(saved.leaveAssistantLastAutoKey===message.autoKey){
          reply({ok:true,duplicate:true});return;
        }
      }
      const serviceId=String(message.serviceId||message.data?.serviceId||"student_leave");
      const targetUrl=globalThis.HaiAgentServices.getTargetUrl(serviceId);
      const tab=await chrome.tabs.create({url:"about:blank",active:message.activate===false?false:!!fromChat});
      const pending={data:message.data,serviceId,targetTabId:tab.id};
      if(message.autoKey)pending.autoKey=message.autoKey;
      const store={leaveAssistantPending:pending};
      if(message.autoKey)store.leaveAssistantLastAutoKey=message.autoKey;
      await chrome.storage.session.set(store);
      await chrome.tabs.update(tab.id,{url:targetUrl});
      reply({ok:true,tabId:tab.id});
    })().catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if(message?.type==="LEAVE_GET_PENDING"||message?.type==="APPLY_GET_PENDING"){
    chrome.storage.session.get("leaveAssistantPending").then(result=>{
      const pending=result.leaveAssistantPending;
      reply({
        data:pending?.targetTabId===sender.tab?.id?(pending.data||null):null,
        serviceId:pending?.targetTabId===sender.tab?.id?(pending.serviceId||""):""
      });
    });
    return true;
  }
  if(message?.type==="LEAVE_CLEAR_PENDING"||message?.type==="APPLY_CLEAR_PENDING"){
    chrome.storage.session.get("leaveAssistantPending").then(result=>{
      if(result.leaveAssistantPending?.targetTabId===sender.tab?.id)
        return chrome.storage.session.remove("leaveAssistantPending");
    }).then(()=>reply({ok:true}));
    return true;
  }
  if(message?.type==="LEAVE_CLICK_START"){
    const tabId=sender.tab?.id,pageUrl=sender.tab?.url;
    if(!tabId||!pageUrl?.startsWith("https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/")){
      reply({ok:false,error:"只能在海南大学学生请假列表页点击发起按钮。"});return;
    }
    chrome.scripting.executeScript({
      target:{tabId},world:"MAIN",
      func:async()=>{
        const normalize=value=>String(value||"").replace(/[\s\u00a0]/g,"");
        const visible=el=>!!el&&el.getClientRects().length>0&&getComputedStyle(el).visibility!=="hidden";
        const waitForForm=async(timeout=4000)=>{
          const until=Date.now()+timeout;
          while(Date.now()<until){
            const form=document.querySelector("#add-form-qjxx");
            const dialogTitle=[...document.querySelectorAll('[bh-paper-pile-dialog-role="bhPaperPileDialogHeader"]')]
              .find(el=>visible(el)&&normalize(el.textContent).includes("发起请假"));
            if(visible(form)&&dialogTitle)return true;
            await new Promise(resolve=>setTimeout(resolve,100));
          }
          return false;
        };
        const candidates=[...document.querySelectorAll('[data-action="我要请假"],a,button,[role="button"]')];
        const button=candidates.find(el=>visible(el)&&normalize(el.getAttribute("data-action")).includes("我要请假"))||
          candidates.find(el=>visible(el)&&normalize(el.innerText||el.textContent).includes("我要请假")&&normalize(el.innerText||el.textContent).length<40);
        if(!button)return {ok:false,error:"当前列表页没有找到可见的“我要请假”按钮。"};

        // The live page binds this control through jQuery's delegated body handler.
        // Trigger the exact control first, as this follows the same event path as
        // the in-page anchor and lets the application retain its current view state.
        const pageJQuery=window.jQuery||window.$;
        if(typeof pageJQuery==="function"){
          pageJQuery(button).trigger("click");
          if(await waitForForm())return {ok:true,via:"jquery-delegated-click"};
        }
        button.click();
        if(await waitForForm())return {ok:true,via:"native-click"};

        // Last fallback: use the page module handler. A handler error must not
        // suppress the already-defined click fallbacks or be reported as success.
        const amdRequire=window.requirejs||window.require;
        if(typeof amdRequire==="function"){
          const invoked=await new Promise(resolve=>{
            let settled=false;
            const finish=value=>{if(settled)return;settled=true;clearTimeout(timer);resolve(value);};
            const timer=setTimeout(()=>finish(null),5000);
            try{
              amdRequire(["modules/wdqj/wdqj"],view=>{
                if(typeof view?.actionGotoAddNew!=="function")return finish(null);
                try{view.actionGotoAddNew.call(view);finish({ok:true,via:"page-handler"});}
                catch(error){finish({ok:false,error:error?.message||String(error)});}
              },()=>finish(null));
            }catch{finish(null);}
          });
          if(invoked?.ok&&await waitForForm())return invoked;
        }
        return {ok:false,error:"已触发列表页的“我要请假”，但未检测到“发起请假”弹窗及 #add-form-qjxx。"};
      }
    }).then(results=>reply(results?.[0]?.result||{ok:false,error:"没有收到页面点击结果。"}))
      .catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
  if(message?.type==="LEAVE_SET_PAGE_FIELDS"){
    const tabId=sender.tab?.id, pageUrl=sender.tab?.url;
    if(!tabId||!pageUrl?.startsWith("https://ehall.hainanu.edu.cn/xsfw/sys/xsqjapp/")){
      reply({ok:false,error:"仅允许在海南大学学生请假页面设置字段。"});return;
    }
    chrome.scripting.executeScript({
      target:{tabId},world:"MAIN",
      func:async(data)=>{
        const $=window.jQuery||window.$;
        if(!$||!$.fn?.emapForm||!$.fn?.jqxCalendar)return {ok:false,error:"学校表单组件尚未就绪。"};
        const form=$("#add-form-qjxx"),calendar=$("#qjxx-calendar");
        if(!form.length||!calendar.length)return {ok:false,error:"请假表单或日期日历未找到。"};
        const mode=data.leaveMode==="按节次"?"2":"1";
        try{
          let leaveTypeReady=false,leaveTypeLabel="",leaveTypeError="";
          const wantedType=data.leaveType==="病假"?"病假":data.leaveType==="事假"?"事假":"";
          if(wantedType){
            const normalize=value=>String(value||"").replace(/[\s\u00a0：:，,（）()【】*?？]/g,"");
            const typeField=form.find('[data-field="QJLX"]').first();
            const matchesWanted=value=>{
              const text=normalize(value);
              if(!text)return false;
              if(text===normalize(wantedType)||text.includes(normalize(wantedType)))return true;
              return (wantedType==="病假"?["因病","疾病","医疗"]:["因事","私事"]).some(alias=>text.includes(normalize(alias)));
            };
            const typeWidgetInfo=(()=>{
              const found=[];
              const add=element=>{
                const widget=$(element);
                if(!widget.length)return;
                const method=typeof widget.jqxDropDownList==="function"?"jqxDropDownList":
                  typeof widget.jqxComboBox==="function"?"jqxComboBox":null;
                if(!method)return;
                if(!found.some(item=>item.widget[0]===widget[0]))found.push({widget,method});
              };
              form.find('[data-name="QJLX"], #QJLX, [name="QJLX"]').each((_,element)=>{
                add(element);
                const closest=widget=>widget.closest(".jqx-dropdownlist, .jqx-widget")[0];
                add(closest($(element)));
                add($(element).closest('[data-field="QJLX"]').find(".jqx-dropdownlist, .jqx-widget")[0]);
              });
              if(!found.length&&typeField.length){
                typeField.find(".jqx-dropdownlist, .jqx-widget").each((_,element)=>add(element));
              }
              if(!found.length){
                form.find(".jqx-dropdownlist").each((_,element)=>{
                  const widget=$(element);
                  const field=widget.closest("[data-field]");
                  const fieldName=String(field.attr("data-field")||"").toUpperCase();
                  if(fieldName==="QJLX"||normalize(field.text()).includes(normalize("请假类型")))add(element);
                });
              }
              return found[0]||$();
            })();
            const typeWidget=typeWidgetInfo?.widget||$();
            const typeWidgetMethod=typeWidgetInfo?.method||"";
            if(typeWidget.length&&typeWidgetMethod){
              let items=[],dropdownOpened=false;
              for(let i=0;i<80;i++){
                try{items=typeWidget[typeWidgetMethod]("getItems")||[];}catch{}
                if(items.length)break;
                if(i===5&&!dropdownOpened){
                  try{typeWidget[typeWidgetMethod]("open");dropdownOpened=true;}catch{}
                }
                await new Promise(resolve=>setTimeout(resolve,100));
              }
              if(dropdownOpened){
                try{typeWidget[typeWidgetMethod]("close");}catch{}
              }
              const entries=items.map((item,index)=>{
                const label=String(typeof item==="string"?item:(item?.label??item?.title??""));
                return {item,index,label};
              }).filter(entry=>!entry.item?.disabled);
              const exact=entries.filter(entry=>normalize(entry.label)===normalize(wantedType));
              const candidates=exact.length?exact:entries.filter(entry=>matchesWanted(entry.label));
              if(!candidates.length){
                const labels=entries.map(entry=>entry.label).filter(Boolean).slice(0,10).join("、");
                leaveTypeError="请假类型下拉选项未匹配“"+wantedType+"”"+(labels?"；当前选项："+labels:"；控件暂未加载到选项");
              }else{
                const match=candidates[0];
                const rawIndex=Number(match.item?.index);
                const selectedIndex=Number.isInteger(rawIndex)?rawIndex:match.index;
                const selectedValue=match.item?.value??match.item?.id??match.label;
                try{typeWidget[typeWidgetMethod]("selectIndex",selectedIndex);}catch{}
                if(match.item&&typeof match.item==="object"){
                  try{typeWidget[typeWidgetMethod]("selectItem",match.item);}catch{}
                }
                try{form.emapForm("setValue",{QJLX:String(selectedValue??"")});}catch{}
                try{typeWidget.trigger("change");typeWidget.trigger("select");}catch{}
                typeWidget.find("input,select").add(typeField.find('input[name="QJLX"],select[name="QJLX"]')).each((_,element)=>{
                  element.dispatchEvent(new Event("input",{bubbles:true}));
                  element.dispatchEvent(new Event("change",{bubbles:true}));
                });
                await new Promise(resolve=>setTimeout(resolve,250));
                let selected=null;
                try{selected=typeWidget[typeWidgetMethod]("getSelectedItem");}catch{}
                leaveTypeLabel=String(selected?.label||typeWidget.find(".jqx-dropdownlist-content").text()||match.label||"").trim();
                const values=form.emapForm("getValue");
                const formValue=values?.QJLX;
                leaveTypeReady=matchesWanted(leaveTypeLabel)&&formValue!==undefined&&formValue!==null&&String(formValue)!=="";
                if(!leaveTypeReady){
                  leaveTypeError="已定位请假类型下拉并尝试选择“"+wantedType+"”，但页面未确认；组件标签“"+leaveTypeLabel+"”，表单值“"+String(formValue??"")+"”";
                }
              }
            }else{
              const nativeSelect=(typeField.find('select[name="QJLX"], select[data-name="QJLX"], select#QJLX').first().length?
                typeField.find('select[name="QJLX"], select[data-name="QJLX"], select#QJLX').first():
                form.find('select[name="QJLX"], select[data-name="QJLX"], select#QJLX').first());
              if(nativeSelect.length){
                const options=[...nativeSelect[0].options].map((option,index)=>({option,index,label:String(option.textContent||"").trim()}))
                  .filter(entry=>!entry.option.disabled);
                const exact=options.filter(entry=>normalize(entry.label)===normalize(wantedType));
                const candidates=exact.length?exact:options.filter(entry=>matchesWanted(entry.label));
                if(candidates.length){
                  const match=candidates[0];
                  nativeSelect[0].selectedIndex=match.index;
                  nativeSelect.trigger("input").trigger("change");
                  try{form.emapForm("setValue",{QJLX:String(match.option.value??match.label)});}catch{}
                  await new Promise(resolve=>setTimeout(resolve,150));
                  leaveTypeLabel=String(nativeSelect[0].selectedOptions?.[0]?.textContent||"").trim();
                  const values=form.emapForm("getValue");
                  leaveTypeReady=matchesWanted(leaveTypeLabel)&&String(values?.QJLX??"")!=="";
                  if(!leaveTypeReady)leaveTypeError="已尝试选择原生下拉框中的“"+wantedType+"”，但表单未确认。";
                }else{
                  leaveTypeError="原生请假类型下拉框中未找到“"+wantedType+"”选项。";
                }
              }else{
                leaveTypeError="未找到请假类型下拉控件；已检查 QJLX、data-name、data-field 和 jqx 下拉。";
              }
            }
          }else leaveTypeError="识别结果缺少请假类型（病假/事假）。";
          const validPhone=value=>/^1[3-9]\d{9}$/.test(String(value||""));
          if(validPhone(data.phone))form.emapForm("setValue",{SJH:String(data.phone)});
          form.emapForm("setValue",{QJFS:mode});
          if(mode==="2")form.emapForm("showItem",["QJJC"]);
          else form.emapForm("hideItem",["QJJC"]);
          await new Promise(resolve=>setTimeout(resolve,100));
          const current=calendar.jqxCalendar("specialDates");
          if(!Array.isArray(current))return {ok:false,error:"无法读取日历选中日期。"};
          if(data.dates?.length){
            current.splice(0,current.length);
            calendar.jqxCalendar("refresh");
            for(const iso of data.dates){
              const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
              if(!m)return {ok:false,error:"日期格式无效。"};
              calendar.jqxCalendar("addSpecialDate",new Date(+m[1],+m[2]-1,+m[3],12),"","请假日期");
            }
          }
          const selected=calendar.jqxCalendar("specialDates");
          const days=Array.isArray(selected)?selected.length:0;
          if(days)form.emapForm("setValue",{QJTS:days});
          const values=form.emapForm("getValue");
          const actual=Number(values?.QJTS||0);
          const phoneReady=validPhone(values?.SJH);
          return {ok:true,mode:String(values?.QJFS)==="2"?"按节次":"按天",days,daysValue:actual,
            dayCountOk:days===0||actual===days,phoneReady,leaveTypeReady,leaveTypeLabel,leaveTypeError};
        }catch(e){return {ok:false,error:e?.message||String(e)};}
      },args:[message.data||{}]
    }).then(results=>reply(results?.[0]?.result||{ok:false,error:"没有收到页面设置结果。"}))
      .catch(error=>reply({ok:false,error:error?.message||String(error)}));
    return true;
  }
});
