(() => {
  let lastSeenLaunch = "";
  let scanTimer = 0;
  let initialScanDone = false;
  let lastPointerLaunch = { key: "", at: 0 };
  const normalize = value => String(value||"").trim().replace(/[\s\u00a0，。！？；：,!?;:]/g,"");
  function decodeB64Json(token){
    if(!token)return null;
    try{
      if(token.startsWith("%7B")||token.startsWith("{"))return JSON.parse(decodeURIComponent(token));
      const b64=token.replace(/-/g,"+").replace(/_/g,"/").padEnd(Math.ceil(token.length/4)*4,"=");
      const binary=atob(b64),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
      return JSON.parse(new TextDecoder().decode(bytes));
    }catch{return null;}
  }
  function decodeFileList(token){
    const value=decodeB64Json(token);
    return Array.isArray(value)?value.filter(item=>item&&typeof item.url==="string"&&/^https:\/\//i.test(item.url)):[];
  }
  const LEAVE_LINK_SELECTOR='a[href*="/api/v1/hainanu/leave/launch#"],a[href*="api/v1/hainanu/leave/launch#"],a[href*="#leavePrefill="],a[href*="#applyPrefill="]';
  function decodeLaunch(link){
    try{
      const normalized=globalThis.HaiAgentPrefill?.parseUrl(link);
      if(normalized?.data){
        return {...normalized.data,files:normalized.files||[],serviceId:normalized.serviceId||"student_leave"};
      }
      const url=new URL(link,location.href), hash=url.hash.replace(/^#/,"");
      const queryAt=hash.indexOf("?");
      const params=new URLSearchParams(queryAt>=0?hash.slice(queryAt+1):hash);
      const token=params.get("leavePrefill")||(queryAt<0?hash:"");
      if(!token)return null;
      let payload=decodeB64Json(token);
      if(!payload)return null;
      if(payload?.data&&typeof payload.data==="object"&&!payload.leaveType)payload=payload.data;
      if(payload?.expiresAt&&Date.now()>Date.parse(payload.expiresAt))return null;
      const linkFiles=decodeFileList(params.get("leaveFiles"));
      payload.files=Array.isArray(payload.files)?payload.files:linkFiles;
      return payload;
    }catch{return null;}
  }
  function buildTask(data,usersText){
    if(!data||typeof data!=="object")return null;
    const serviceId=String(data.serviceId||"student_leave");
    if(serviceId!=="student_leave"){
      return {
        ...data,
        serviceId,
        files:(Array.isArray(data.files)?data.files:[]).filter(item=>item&&typeof item.url==="string"&&/^https:\/\//i.test(item.url)),
        autoAdvance:data.autoAdvance??data.auto_advance??true,
        stopBeforeSubmit:true
      };
    }
    const iso=s=>typeof s==="string"&&/^\d{4}-\d{2}-\d{2}$/.test(s);
    if(!data.leaveType||!iso(data.startDate)||!iso(data.endDate)||!data.reason)return null;
    const destination=data.destination||[data.destinationCountry,data.destinationRegion,data.destinationAddress].filter(Boolean).join(" / ");
    const explicitAway=data.outside==="否"||data.outside==="是"?data.outside:"";
    const away=explicitAway||(/不外出|不出校|不离校/.test(usersText)||/校医院/.test(destination)?"否":(data.crossCampus==="否"?"请核对":""));
    const phone=String(data.phone||usersText.match(/(?:^|\D)(1[3-9]\d{9})(?!\d)/)?.[1]||"");
    const files=(Array.isArray(data.files)?data.files:[]).filter(item=>item&&typeof item.url==="string"&&/^https:\/\//i.test(item.url));
    return {
      serviceId,
      leaveType:String(data.leaveType),leaveMode:data.leaveMode==="按节次"?"按节次":"按天",
      startDate:data.startDate,startPart:String(data.startPhase||data.startPart||""),
      endDate:data.endDate,endPart:String(data.endPhase||data.endPart||""),
      reason:String(data.reason),phone,outside:away,destination,
      files,
      hasAttachment:typeof data.hasAttachment==="string"&&data.hasAttachment?data.hasAttachment:
        (files.length?`工作流已提供${files.length}个附件`:(/附件|病历|证明材料/.test(usersText)?"对话提到附件；未读取到附件文件":"未提到附件"))
    };
  }
  function readTextSummary(text){
    const type=text.match(/请假类型\s*[：:]\s*(病假|事假)/)?.[1]||"";
    const dates=[...text.matchAll(/\b(20\d{2}-\d{2}-\d{2})\b/g)].map(m=>m[1]);
    const reason=text.match(/请假事由\s*[：:]\s*([^\n。]+)/)?.[1]?.trim()||"";
    const destination=text.match(/目的地\s*[：:]\s*([^\n。]+)/)?.[1]?.trim()||"";
    const time=text.match(/请假时间\s*[：:]\s*([^\n]+)/)?.[1]||"";
    const phases=[...time.matchAll(/上午|早上|中午|下午|晚上/g)].map(m=>m[0]);
    if(!type||dates.length<2||!reason)return null;
    return {leaveType:type,startDate:dates[0],endDate:dates[1],startPhase:phases[0]||"",endPhase:phases[1]||phases[0]||"",reason,destination};
  }
  function getConfirmedTask(force=false){
    const isInitialScan=!initialScanDone;
    const root=document.querySelector("#chat-container")||document.querySelector("main");
    if(!root)return {error:"未找到小海对话区域。"};
    const users=[...root.querySelectorAll(".chat-user,[data-message-author-role='user']")];
    const assistants=[...root.querySelectorAll(".chat-assistant,[data-message-author-role='assistant']")];
    const lastUser=users.at(-1),lastAssistant=assistants.at(-1);
    if(!lastUser||!lastAssistant)return {error:"未找到完整的用户消息和助手回复。请刷新小海页面后重试。"};
    initialScanDone=true;
    const confirmation=normalize(lastUser.innerText||lastUser.textContent||"");
    if(!/^(确认|确认无误|确认提交|确认请假)$/.test(confirmation))return {error:"请先在小海对话中回复“确认”，再让助手生成请假入口。"};
    const assistantText=lastAssistant.innerText||lastAssistant.textContent||"";
    const link=[...lastAssistant.querySelectorAll(LEAVE_LINK_SELECTOR)].at(-1);
    const key=link?.href?`${lastUser.id||users.length}|${link.href}`:`${lastUser.id||users.length}|${assistantText}`;
    if(isInitialScan&&!force){lastSeenLaunch=key;return {error:"已连接，但当前入口在扩展启动前就已存在。点击再次识别可继续。"};}
    const payload=(link&&decodeLaunch(link.href))||readTextSummary(assistantText);
    if(!payload)return {error:"最新助手回复中没有可解析的最终请假信息。请确认助手已输出请假类型、日期和事由。"};
    const usersText=users.map(el=>el.innerText||el.textContent||"").join("\n");
    const task=buildTask(payload,usersText);
    if(!task)return {error:"已找到入口，但其中缺少必需的请假类型、有效日期或事由。"};
    return {task,key,linkHref:link?.href||""};
  }
  function scanForConfirmedLaunch(){
    const result=getConfirmedTask();
    if(!result?.task)return;
    const key=launchKey(result.task,result.linkHref);
    if(key===lastSeenLaunch)return;
    lastSeenLaunch=key;
    launchTask(result.task,{href:result.linkHref,activate:true,autoDedupe:true}).then(response=>{
      if(!response?.ok){lastSeenLaunch="";console.warn("学生请假助手未能启动：",response?.error||"未知错误");}
    }).catch(()=>{lastSeenLaunch="";});
  }
  function scheduleScan(){clearTimeout(scanTimer);scanTimer=setTimeout(scanForConfirmedLaunch,500);}

  function launchKey(task,href=""){
    return `${task.serviceId||"student_leave"}|${href||task.startDate||""}|${task.reason||task.title||""}`;
  }

  function launchTask(task,{href="",activate=true,autoDedupe=false}={}){
    const message={
      type:"LEAVE_OPEN_NEW_TAB",
      serviceId:task.serviceId,
      data:task,
      activate
    };
    if(autoDedupe){
      const key=launchKey(task,href);
      lastSeenLaunch=key;
      message.autoKey=key;
    }
    return chrome.runtime.sendMessage(message);
  }

  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if(message?.type==="LEAVE_PING")return reply({ok:true,ready:true});
    if(message?.type==="LEAVE_LAUNCH_CONFIRMED"){
      const result=getConfirmedTask(true);
      if(!result?.task)return reply({ok:false,error:result?.error||"无法识别当前请假对话。"});
      lastSeenLaunch=launchKey(result.task,result.linkHref);
      launchTask(result.task,{href:result.linkHref,activate:false,autoDedupe:true})
        .then(reply).catch(error=>reply({ok:false,error:error?.message||String(error)}));
      return true;
    }
    if(message?.type==="LEAVE_READ_CHAT"){
      const root = document.querySelector("#chat-container") || document.querySelector("main");
      const text = (root?.innerText || document.body.innerText || "").trim();
      if (!text) return reply({ok:false, error:"当前页面没有可读取的对话文字。"});
      reply({ok:true, text:text.slice(-30000)});
    }
  });
  const observer=new MutationObserver(scheduleScan);
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
  function interceptPrefillLink(event){
    if(event.type==="pointerdown"||event.type==="mousedown"){
      if(event.button!==0)return;
    }else if(event.type==="auxclick"){
      if(event.button!==1)return;
    }else if(event.type==="click"&&event.button!==0){
      return;
    }
    const link=event.target?.closest?.(LEAVE_LINK_SELECTOR);
    if(!link)return;
    const payload=decodeLaunch(link.href);
    if(!payload)return;
    const task=buildTask(payload,document.body.innerText||"");
    if(!task)return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    const now=Date.now();
    const key=launchKey(task,link.href);
    if(
      (event.type==="mousedown"||event.type==="click")&&
      lastPointerLaunch.key===key&&
      now-lastPointerLaunch.at<1000
    )return;
    if(event.type==="pointerdown"||event.type==="mousedown"||event.type==="auxclick"){
      lastPointerLaunch={key,at:now};
    }
    launchTask(task,{href:link.href,activate:true,autoDedupe:false})
      .catch(error=>console.warn("学生请假助手未能启动：",error?.message||String(error)));
  }
  for(const eventName of ["pointerdown","mousedown","auxclick","click"]){
    document.addEventListener(eventName,interceptPrefillLink,true);
  }
  // Direct prefill URLs are redirected in-place by worker.js. Do not open
  // another tab here, because that creates a duplicate business-system page.
  scheduleScan();
})();
