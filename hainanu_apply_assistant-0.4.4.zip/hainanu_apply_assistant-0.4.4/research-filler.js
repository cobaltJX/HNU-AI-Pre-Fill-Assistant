(() => {
  const SERVICE_ID = "research_paper_registration";
  const SHOW_STATUS = false;
  const REVIEW_REACHED_KEY = "haiResearchReachedReview";
  const RESEARCH_SERVICE_ID = "2c92bcb167c916610167c91960700004";
  const PAPER_MODE_IDS = { 期刊论文: "1", 会议论文: "2", 文章: "4" };
  const SUBJECT_CLASS_IDS = { 社科类: "1", 科技类: "2", 平台类: "3" };
  const PUBLISH_RANGE_IDS = {
    国外学术刊物: "1",
    国内公开发行: "2",
    国内外公开发行: "3",
    港澳台刊物: "4"
  };
  const SCHOOL_SIGN_IDS = { 第一单位: "0", 非第一单位: "1" };
  const AUTHOR_TYPE_IDS = { 教师: "1", 学生: "2", 校外: "3" };
  const AUTHOR_EDU_IDS = { 博士研究生: "0", 硕士研究生: "1", 本科: "2", 其他: "5" };
  const AUTHOR_ROLE_IDS = {
    "第一作者（唯一）": "0",
    "共同第一作者（排第一）": "1",
    通讯作者: "2",
    "第一及通讯作者": "4",
    "共同通讯作者（排第一）": "5",
    "共同第一作者（非第一）": "6",
    "共同通讯作者（非第一）": "7",
    参与作者: "3"
  };
  const AUTHOR_TITLE_IDS = {
    教授: "1A",
    副教授: "2A",
    "讲师（高校）": "3A",
    "助教（高校）": "4",
    初级: "5",
    其他人员: "7",
    高级工程师: "1B",
    工程师: "3B",
    助理工程师: "4B",
    研究员: "1C2",
    "研究员（自然科学）": "1C2",
    "副研究员（自然科学）": "2C2",
    "助理研究员（自然科学）": "3C2"
  };
  const SCI_PARTITION_IDS = { 一区: "1", 二区: "2", 三区: "3", 四区: "4" };
  const EMBODY_TYPE_IDS = {
    SCI: "1",
    CSCD: "52a5a90965e6df0e01662dd24f6c31d5",
    "CCF(国际)": "fd59de708841119601884274b1a10017",
    "CCF(高质量)": "fd59de7088468aac018846923dde0000",
    "CSSCI(扩展)": "fd59de7088468aac018846932dd80001",
    北核: "fd59de708a26507f018a449f37030acb",
    北核扩展版: "fd59de708a26507f018a449f9c030acc",
    EI: "2",
    SSCI: "3",
    ISTP: "4",
    "CSSCI(来源)": "5",
    SCIE: "6",
    "A&HCI": "8",
    ISSHP: "9",
    未收录: "52a5a909507e942801508d740a334694"
  };

  const clean = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
  const norm = (value) =>
    clean(value)
      .toLowerCase()
      .replace(/[\s\u00a0：:，,（）()【】*?？/\\_-]/g, "");
  const visible = (element) =>
    !!element &&
    !!element.getClientRects().length &&
    getComputedStyle(element).visibility !== "hidden";
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  let step1CompletionTimer = null;

  const createTaskId = () =>
    globalThis.crypto?.randomUUID?.() ||
    `research-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

  const reviewReached = () => {
    try {
      return sessionStorage.getItem(REVIEW_REACHED_KEY) === "1";
    } catch {
      return false;
    }
  };

  const clearReviewReached = () => {
    try {
      sessionStorage.removeItem(REVIEW_REACHED_KEY);
    } catch {}
  };

  const stopStep1Watcher = () => {
    if (step1CompletionTimer === null) return;
    clearInterval(step1CompletionTimer);
    step1CompletionTimer = null;
  };

  const clearPendingTask = () =>
    chrome.runtime.sendMessage({ type: "APPLY_CLEAR_PENDING" }).catch(() => {});

  const setText = (name, value) => {
    const text = String(value ?? "").trim();
    if (!text) return false;
    const element = document.querySelector(`[name="${CSS.escape(name)}"]`);
    if (!element || element.disabled || element.readOnly || !visible(element)) return false;
    const prototype =
      element.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (!setter) return false;
    setter.call(element, text);
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    return element.value === text;
  };

  const setSelect = (name, value, fallbackText = "") => {
    const select = document.querySelector(`select[name="${CSS.escape(name)}"]`);
    if (!select || select.disabled || !visible(select)) return false;
    const wanted = norm(value);
    const wantedText = norm(fallbackText);
    const option = [...select.options].find((item) => {
      const valueText = norm(item.value);
      const labelText = norm(item.textContent);
      return (
        (wanted && (valueText === wanted || labelText === wanted)) ||
        (wantedText && labelText === wantedText)
      );
    });
    if (!option) return false;
    select.value = option.value;
    select.dispatchEvent(new Event("input", { bubbles: true }));
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return select.value === option.value;
  };

  const chooseRadio = (name, value) => {
    const wanted = String(value ?? "").trim();
    if (!wanted) return false;
    const input = [...document.querySelectorAll(`input[type="radio"][name="${CSS.escape(name)}"]`)].find(
      (item) => item.value === wanted
    );
    if (!input || input.disabled) return false;
    input.click();
    return input.checked;
  };

  const chooseCheckboxes = (name, values) => {
    const wanted = (Array.isArray(values) ? values : values ? [values] : [])
      .map((item) => clean(item))
      .filter(Boolean);
    if (!wanted.length) return false;
    const inputs = [...document.querySelectorAll(`input[type="checkbox"][name="${CSS.escape(name)}"]`)];
    let selected = 0;
    for (const input of inputs) {
      const checkboxLabel = clean(
        input.closest("label")?.innerText || input.nextSibling?.textContent || ""
      );
      const matched = wanted.some(
        (item) =>
          norm(item) === norm(input.value) ||
          norm(item) === norm(checkboxLabel) ||
          EMBODY_TYPE_IDS[item] === input.value
      );
      if (!matched || input.disabled) continue;
      if (!input.checked) input.click();
      if (input.checked) selected += 1;
    }
    return selected > 0;
  };

  const setSelectRetry = async (name, value, fallbackText = "") => {
    for (let attempt = 0; attempt < 20; attempt += 1) {
      if (setSelect(name, value, fallbackText)) {
        const selected = document.querySelector(`select[name="${CSS.escape(name)}"]`);
        const expected = selected?.value || "";
        await wait(180);
        if (selected?.value === expected) return true;
      }
      await wait(100);
    }
    return false;
  };

  const setTextWithRetry = async (name, value) => {
    const expected = String(value ?? "").trim();
    for (let attempt = 0; attempt < 20; attempt += 1) {
      if (setText(name, expected)) {
        await wait(180);
        if (valueOf(name) === expected) return true;
      }
      await wait(100);
    }
    return false;
  };

  const findButton = (text, exact = false) =>
    [...document.querySelectorAll("button,input[type=button],a.btn,[role=button]")].find((element) => {
      if (!visible(element) || element.disabled) return false;
      const value = clean(element.innerText || element.value || element.textContent);
      return exact ? value === text : value.includes(text);
    });

  const clickButton = (text, exact = false) => {
    const button = findButton(text, exact);
    if (!button) return false;
    button.click();
    return true;
  };

  const valueOf = (name) => {
    const element = document.querySelector(`[name="${CSS.escape(name)}"]`);
    return element ? String(element.value || "") : "";
  };

  const checkedValue = (name) =>
    document.querySelector(`input[type="radio"][name="${CSS.escape(name)}"]:checked`)?.value || "";

  const modeId = (data) => {
    if (data.modeId) return String(data.modeId);
    return PAPER_MODE_IDS[clean(data.paperMode || data.paper_type || data.paperType)] || "";
  };
  const subjectClassId = (data) => {
    if (data.subjectClassId) return String(data.subjectClassId);
    return SUBJECT_CLASS_IDS[clean(data.subjectCategory || data.statistical_category)] || "";
  };
  const publishRangeId = (data) => {
    if (data.publishRangeId) return String(data.publishRangeId);
    return PUBLISH_RANGE_IDS[clean(data.publishRange)] || "";
  };
  const schoolSign = (data) => {
    if (data.schoolSign !== undefined && data.schoolSign !== null && data.schoolSign !== "") {
      return String(data.schoolSign);
    }
    return SCHOOL_SIGN_IDS[clean(data.schoolSignature || data.school_sign)] || "";
  };
  const sciPartitionId = (data) => {
    if (data.sciPartitionId) return String(data.sciPartitionId);
    return SCI_PARTITION_IDS[clean(data.sciPartition || data.sci_partition)] || "";
  };
  const sciPartitionSubclassId = (data) => {
    if (data.sciPartitionSubclassId) return String(data.sciPartitionSubclassId);
    return (
      SCI_PARTITION_IDS[
        clean(data.sciPartitionSubclass || data.sci_partition_subclass || data.sciSubclass)
      ] || ""
    );
  };
  const isTopId = (data) => {
    if (data.isTopId !== undefined && data.isTopId !== null && data.isTopId !== "") {
      return String(data.isTopId);
    }
    if (typeof data.isTop === "boolean") return data.isTop ? "1" : "0";
    return clean(data.isTop || data.is_top) === "是"
      ? "1"
      : clean(data.isTop || data.is_top) === "否"
        ? "0"
        : "";
  };
  const volumePage = (data) =>
    clean(
      data.juanQiYe ||
        data.juan_qi_ye ||
        [data.volume, data.issue, data.pages].filter((item) => clean(item)).join(" / ")
    );

  const currentStep = () => {
    const parameter = Number(new URL(location.href).searchParams.get("curStepNum"));
    if (Number.isInteger(parameter) && parameter >= 1 && parameter <= 4) return parameter;
    if (location.pathname.includes("paperAction!to_finishStep.action")) return 4;
    if (location.pathname.includes("paperAction!to_supportProjectAdd.action")) return 3;
    if (location.pathname.includes("paperAction!to_paperEmbodyManageAdd.action")) return 2;
    const hasTitle = document.querySelector('input[name="entity.name"]');
    if (location.pathname.includes("paperAction!to_add.action") || hasTitle) return 1;
    return 0;
  };

  const visibleErrors = () => {
    const messages = [...document.querySelectorAll("[name=errormsg],.help-block,.has-error")]
      .filter((element) => visible(element))
      .map((element) => clean(element.textContent))
      .filter(Boolean);
    return [...new Set(messages)].slice(0, 12);
  };

  const announce = (message, { error = false, progress = "" } = {}) => {
    if (!SHOW_STATUS) {
      if (error) console.warn(`[小海科研论文登记] ${message}`);
      return;
    }
    let box = document.getElementById("hai-research-filler-status");
    if (!box) {
      box = document.createElement("div");
      box.id = "hai-research-filler-status";
      Object.assign(box.style, {
        position: "fixed",
        zIndex: "2147483647",
        top: "12px",
        right: "12px",
        maxWidth: "480px",
        whiteSpace: "pre-wrap",
        padding: "12px 16px",
        borderRadius: "8px",
        boxShadow: "0 3px 16px #0003",
        background: error ? "#fff1f2" : "#f0f7ff",
        color: error ? "#991b1b" : "#173b5b",
        font: "13px/1.55 system-ui,sans-serif"
      });
      const close = document.createElement("button");
      close.type = "button";
      close.textContent = "关闭";
      close.style.cssText =
        "float:right;margin-left:12px;border:1px solid #9cb5cc;border-radius:5px;background:white;padding:3px 8px;cursor:pointer";
      close.addEventListener("click", () => box.remove());
      const title = document.createElement("strong");
      title.id = "hai-research-filler-title";
      const text = document.createElement("div");
      text.id = "hai-research-filler-text";
      text.style.marginTop = "5px";
      box.append(close, title, text);
      document.documentElement.append(box);
    }
    box.style.background = error ? "#fff1f2" : "#f0f7ff";
    box.style.color = error ? "#991b1b" : "#173b5b";
    document.getElementById("hai-research-filler-title").textContent =
      progress ? `小海科研论文登记 · ${progress}` : "小海科研论文登记";
    document.getElementById("hai-research-filler-text").textContent = message;
  };

  const waitForForm = async (timeout = 30000) => {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const title = document.querySelector('input[name="entity.name"]');
      if (title && visible(title)) return title;
      await wait(250);
    }
    return null;
  };

  const filePurpose = (file) => {
    const purpose = norm(file?.purpose || file?.kind || file?.category || file?.field || "");
    if (/paper|fulltext|manuscript|论文全文|正文/.test(purpose)) return "paper";
    if (/certificate|cert|partition|index|journal|收录|分区|检索|证明/.test(purpose)) {
      return "certificate";
    }
    const name = clean(file?.name || file?.filename);
    if (/分区|收录|检索|证明|证书|sci|ei|cscd|certificate|index/i.test(name)) {
      return "certificate";
    }
    return "paper";
  };

  const researchFiles = (data) => {
    const all = [];
    const add = (items, forcedPurpose = "") => {
      for (const item of Array.isArray(items) ? items : []) {
        if (!item || typeof item.url !== "string" || !/^https:\/\//i.test(item.url)) continue;
        const normalized = {
          ...item,
          purpose: item.purpose || item.kind || item.category || forcedPurpose || ""
        };
        if (all.some((existing) => existing.url === normalized.url)) continue;
        all.push(normalized);
      }
    };
    add(data.files);
    add(data.paperFiles || data.paper_files, "paper_fulltext");
    add(
      data.certificateFiles ||
        data.certificate_files ||
        data.indexingCertificateFiles ||
        data.indexing_certificate_files,
      "indexing_certificate"
    );
    return {
      paper: all.filter((item) => filePurpose(item) === "paper"),
      certificate: all.filter((item) => filePurpose(item) === "certificate")
    };
  };

  const fetchFile = async (file) => {
    const response = await chrome.runtime
      .sendMessage({
        type: "APPLY_FETCH_FILE",
        url: file.url,
        name: file.name || file.filename || "附件",
        mimeType: file.mimeType || file.mime_type || ""
      })
      .catch((error) => ({ ok: false, error: error.message || String(error) }));
    if (!response?.ok) throw new Error(response?.error || "附件读取失败");
    return {
      name: response.name || file.name || "附件",
      mimeType: response.mimeType || "application/octet-stream",
      base64: response.base64
    };
  };

  const attachFiles = async (files, field, taskId = "") => {
    if (!files.length) return { uploaded: [], errors: [] };
    const loaded = [];
    const errors = [];
    for (const file of files) {
      try {
        loaded.push(await fetchFile(file));
      } catch (error) {
        errors.push(`${file.name || file.filename || "附件"}：${error.message || String(error)}`);
      }
    }
    if (!loaded.length) return { uploaded: [], errors };
    const result = await chrome.runtime
      .sendMessage({
        type: "APPLY_SET_RESEARCH_FILES",
        field: { ...field, taskId },
        files: loaded
      })
      .catch((error) => ({ ok: false, error: error.message || String(error) }));
    if (!result?.ok) errors.push(result?.error || "科研系统上传控件未接收附件");
    return {
      uploaded: result?.ok ? result.uploaded || loaded.map((file) => file.name) : [],
      alreadyUploaded: result?.alreadyUploaded || [],
      errors
    };
  };

  const authorTitle = (data) =>
    clean(data.authorTitle || data.author_title || data.authorTitleName || data.author_title_name);
  const authorTitleId = (data) => {
    if (data.authorTitleId || data.author_title_id) {
      return String(data.authorTitleId || data.author_title_id);
    }
    return AUTHOR_TITLE_IDS[authorTitle(data)] || "";
  };

  const fillAuthor = (data, done, skipped, defaults) => {
    const title = document.querySelector('select[name="entity.authors[0].titleId"]');
    if (!title) return;
    let titleValue = authorTitleId(data);
    if (!titleValue && !title.value) {
      titleValue = "7";
      defaults.push("作者职称未提供，已使用中性值“其他人员”");
    }
    if (titleValue && setSelect("entity.authors[0].titleId", titleValue, authorTitle(data))) {
      done.push(`作者职称：${title.selectedOptions?.[0]?.textContent.trim() || titleValue}`);
    } else if (titleValue) {
      skipped.push("作者职称：页面选项未匹配");
    }

    const typeId =
      data.authorTypeId ||
      data.author_type_id ||
      AUTHOR_TYPE_IDS[clean(data.authorType || data.author_type || data.authorRole)] ||
      "";
    if (typeId && setSelect("entity.authors[0].authorType", typeId, data.authorType || data.author_type)) {
      done.push("作者类型");
    }
    const eduId =
      data.authorEduLevelId ||
      data.author_edu_level_id ||
      AUTHOR_EDU_IDS[clean(data.authorEduLevel || data.author_edu_level || data.degree)] ||
      "";
    if (
      eduId &&
      setSelect("entity.authors[0].eduLevelId", eduId, data.authorEduLevel || data.degree)
    ) {
      done.push("作者学历");
    }
    const roleId =
      data.authorRoleId ||
      data.author_role_id ||
      AUTHOR_ROLE_IDS[clean(data.authorRole || data.author_role || data.authorPosition)] ||
      "";
    if (
      roleId &&
      setSelect("entity.authors[0].isTxAuthor", roleId, data.authorRole || data.author_role)
    ) {
      done.push("作者角色");
    }

    const firstName =
      clean(data.authorName || data.author_name) || clean(data.authors).split(/[、,，;；]/)[0];
    const nameInput = document.querySelector('input[name="entity.authors[0].authorName"]');
    if (
      firstName &&
      nameInput &&
      !clean(nameInput.value) &&
      setText("entity.authors[0].authorName", firstName)
    ) {
      done.push("作者姓名");
    }
    const unitInput = document.querySelector('input[name="entity.authors[0].authorUnit"]');
    const unitValue = clean(data.authorUnit || data.author_unit || data.unitName);
    if (unitValue && unitInput && !clean(unitInput.value) && setText("entity.authors[0].authorUnit", unitValue)) {
      done.push("作者单位");
    }
    if (clean(data.workRatio || data.work_ratio)) {
      if (setText("entity.authors[0].workRatio", data.workRatio || data.work_ratio)) {
        done.push("作者贡献率");
      }
    }
  };

  const fillStep1 = async (data, files) => {
    const done = [];
    const skipped = [];
    const defaults = [];
    const textFields = [
      ["论文名称", "entity.name", data.paperName || data.title],
      ["发表/出版时间", "entity.publishDate", data.publishDate || data.publication_date],
      ["发表/刊物论文集", "entity.magazineName", data.magazineName || data.journal],
      ["卷期页", "entity.juanQiYe", volumePage(data)],
      ["DOI", "entity.doi", data.doi],
      ["ISSN号", "entity.issn", data.issn],
      ["CN号", "entity.cn", data.cn]
    ];
    for (const [label, name, value] of textFields) {
      if (!clean(value)) continue;
      if (setText(name, value)) done.push(label);
      else skipped.push(`${label}：控件未接受值或不可编辑`);
    }

    const mode = modeId(data);
    if (mode && chooseRadio("entity.modeId", mode)) done.push("论文类型");
    else if (data.paperMode || data.paperType || data.paper_type || data.modeId) {
      skipped.push("论文类型：未匹配");
    }
    if (mode === "2") {
      await wait(300);
      const meetingName = clean(data.meetingName || data.meeting_name || data.conferenceName);
      const meetingAddress = clean(
        data.meetingAddress || data.meeting_address || data.conferenceAddress
      );
      if (meetingName && (await setTextWithRetry("entity.meetingName", meetingName))) {
        done.push("会议名称");
      } else if (meetingName) {
        skipped.push("会议名称：控件未接受值或不可编辑");
      }
      if (meetingAddress && (await setTextWithRetry("entity.meetingAddress", meetingAddress))) {
        done.push("会议地址");
      } else if (meetingAddress) {
        skipped.push("会议地址：控件未接受值或不可编辑");
      }
    }
    if (chooseCheckboxes("entity.embodyTypeId", data.embodyTypes || data.embodyTypeIds)) {
      done.push("收录类别");
      await wait(300);
    } else if (data.embodyTypes?.length || data.embodyTypeIds?.length) {
      skipped.push("收录类别：未匹配页面选项");
    }

    const category = subjectClassId(data);
    if (category && chooseRadio("entity.subjectClassId", category)) done.push("统计归属");
    else if (data.subjectCategory || data.statistical_category) skipped.push("统计归属：未匹配");

    const range = publishRangeId(data);
    if (range && setSelect("entity.publishRangeId", range)) done.push("发表范围");
    else if (data.publishRange) skipped.push("发表范围：未匹配页面选项");

    const sign = schoolSign(data);
    if (sign && chooseRadio("entity.schoolSign", sign)) done.push("学校署名");
    else if (data.schoolSignature || data.school_sign) skipped.push("学校署名：未匹配");

    if (data.unitName || data.unitId) {
      if (setSelect("entity.unitId", data.unitId, data.unitName)) done.push("所属单位");
      else skipped.push("所属单位：未匹配页面选项");
    }
    const embodies = (data.embodyTypes || data.embodyTypeIds || []).map((item) => clean(item));
    const needsSci = embodies.some((item) => /^(SCI|SCIE)$/i.test(item));
    if (needsSci || data.sciPartition || data.sciPartitionId) {
      const partition = sciPartitionId(data);
      if (partition && setSelect("entity.sciPartition", partition, data.sciPartition)) {
        done.push("中科院分区大类");
      } else if (partition) {
        skipped.push("中科院分区大类：未匹配页面选项");
      }
      const subclass = sciPartitionSubclassId(data);
      if (
        subclass &&
        setSelect(
          "entity.sciPartitionSubclass",
          subclass,
          data.sciPartitionSubclass || data.sciSubclass
        )
      ) {
        done.push("中科院分区小类");
      } else if (subclass) {
        skipped.push("中科院分区小类：未匹配页面选项");
      }
      const top = isTopId(data);
      if (top && chooseRadio("entity.isTop", top)) done.push("是否TOP期刊");
    }
    const factor = clean(data.factor || data.impactFactor || data.impact_factor);
    if (factor && (await setTextWithRetry("entity.factor", factor))) done.push("影响因子");
    else if (factor) skipped.push("影响因子：控件未接受值或不可编辑");

    if (data.subjectName || data.subjectId || data.subject_name) {
      if (
        await setSelectRetry(
          "entity.subjectId",
          data.subjectId,
          data.subjectName || data.subject_name
        )
      ) {
        done.push("一级学科");
      } else {
        skipped.push("一级学科：选项未加载或未匹配");
      }
    }
    if (data.projectSource || data.projectSourceId || data.project_source) {
      if (
        await setSelectRetry(
          "entity.projectSourceId",
          data.projectSourceId || data.project_source_id,
          data.projectSource || data.project_source
        )
      ) {
        done.push("项目来源");
      } else {
        skipped.push("项目来源：选项未加载或未匹配");
      }
    }

    fillAuthor(data, done, skipped, defaults);

    const loaded = researchFiles(data);
    const paperUpload = await attachFiles(
      loaded.paper,
      {
        mode: "multiple",
        buttonName: "entity.fileIds_upload",
        inputName: "entity.fileIds"
      },
      data.prefillTaskId
    );
    if (paperUpload.uploaded.length) done.push(`论文全文附件：${paperUpload.uploaded.join("、")}`);
    if (paperUpload.errors.length) {
      skipped.push(...paperUpload.errors.map((item) => `论文全文附件：${item}`));
    }

    const certificateUpload = await attachFiles(
      loaded.certificate,
      {
        mode: "multiple",
        buttonName: "entity.searchCertificate_upload",
        inputName: "entity.searchCertificate"
      },
      data.prefillTaskId
    );
    if (certificateUpload.uploaded.length) {
      done.push(`分区/收录佐证：${certificateUpload.uploaded.join("、")}`);
    }
    if (certificateUpload.errors.length) {
      skipped.push(...certificateUpload.errors.map((item) => `分区/收录佐证：${item}`));
    }

    return {
      done,
      skipped,
      defaults,
      hasPaperFile: paperUpload.uploaded.length > 0,
      hasCertificateFile: certificateUpload.uploaded.length > 0
    };
  };

  const fillStep2 = async (data, files) => {
    const done = [];
    const skipped = [];
    const rows = [
      ...new Set(
        [...document.querySelectorAll('select[name^="entity.paperIncludes["][name$=".embodyTypeId"]')]
          .filter(visible)
          .map((element) => element.name.match(/^entity\.paperIncludes\[(\d+)\]/)?.[1])
          .filter(Boolean)
      )
    ];
    const date = data.publishDate || data.publication_date || "";
    const embodyTypes = data.embodyTypes || data.embodyTypeIds || [];
    const partition = sciPartitionId(data);
    const factor = clean(data.factor || data.impactFactor || data.impact_factor);
    for (const index of rows) {
      const prefix = `entity.paperIncludes[${index}]`;
      const select = document.querySelector(`select[name="${prefix}.embodyTypeId"]`);
      const rowType = clean(select?.value);
      const rowLabel = clean(select?.selectedOptions?.[0]?.textContent);
      if (embodyTypes.length) {
        const matched = embodyTypes.find(
          (item) => norm(item) === norm(rowType) || norm(item) === norm(rowLabel)
        );
        if (matched && setSelect(`${prefix}.embodyTypeId`, rowType, matched)) {
          done.push(`收录类型 ${Number(index) + 1}`);
        }
      }
      if (date && setText(`${prefix}.embodyDate`, date)) done.push(`收录日期 ${Number(index) + 1}`);
      if (partition && setSelect(`${prefix}.sciPartition`, partition, data.sciPartition)) {
        done.push(`收录分区 ${Number(index) + 1}`);
      }
      if (factor && setText(`${prefix}.factor`, factor)) done.push(`影响因子 ${Number(index) + 1}`);
    }
    const certificate = files.certificate?.[0];
    if (certificate && rows.length) {
      const upload = await attachFiles(
        [certificate],
        {
          mode: "simple",
          buttonName: "entity.paperIncludes[0].embodyFileId_upload",
          inputName: "entity.paperIncludes[0].embodyFileId"
        },
        data.prefillTaskId
      );
      if (upload.uploaded.length) done.push("收录证明附件");
      if (upload.errors.length) {
        skipped.push(...upload.errors.map((item) => `收录证明附件：${item}`));
      }
    }
    return { done, skipped };
  };

  const fillStep3 = async (data) => {
    const done = [];
    const skipped = [];
    const desiredIds = data.projectIds || data.project_ids || [];
    const desiredNames = data.projectNames || data.project_names || data.linkedProjects || [];
    if (!desiredIds.length && !desiredNames.length) {
      return { done: ["未指定依托项目，按页面允许空项继续"], skipped };
    }
    const source = document.querySelector("#fromSelect");
    const target = document.querySelector("#toSelect");
    if (!source || !target) return { done, skipped: ["依托项目选择控件未加载"] };
    const ids = new Set(
      (Array.isArray(desiredIds) ? desiredIds : [desiredIds]).map((item) => String(item))
    );
    const names = (Array.isArray(desiredNames) ? desiredNames : [desiredNames])
      .map(norm)
      .filter(Boolean);
    let selected = 0;
    for (const option of source.options) {
      const matched =
        ids.has(String(option.value)) || names.some((name) => norm(option.textContent).includes(name));
      option.selected = matched;
      if (matched) selected += 1;
    }
    if (!selected) {
      skipped.push("依托项目：未在页面可选项目中匹配到工作流提供的数据");
      return { done, skipped };
    }
    source.dispatchEvent(new Event("change", { bubbles: true }));
    const add = document.querySelector("#add");
    if (!add) return { done, skipped: ["依托项目：未找到添加按钮"] };
    add.click();
    await wait(500);
    done.push(`依托项目：已添加 ${target.selectedOptions.length || selected} 项`);
    return { done, skipped };
  };

  const uploadReady = (inputName) =>
    [...document.querySelectorAll(`input[type="file"][name="${CSS.escape(inputName)}"]`)]
      .some((input) => !!input.files?.length);

  const step1Ready = (data) => {
    const missing = [];
    if (!valueOf("entity.name")) missing.push("论文名称");
    if (!valueOf("entity.publishDate")) missing.push("发表/出版时间");
    if (!valueOf("entity.magazineName")) missing.push("刊物/论文集");
    if (!checkedValue("entity.modeId")) missing.push("论文类型");
    if (!document.querySelector('input[name="entity.embodyTypeId"]:checked')) missing.push("收录类别");
    if (!checkedValue("entity.subjectClassId")) missing.push("统计归属");
    if (!valueOf("entity.publishRangeId")) missing.push("发表范围");
    if (!checkedValue("entity.schoolSign")) missing.push("学校署名");
    if (!valueOf("entity.subjectId")) missing.push("一级学科");
    if (checkedValue("entity.modeId") === "2") {
      if (!valueOf("entity.meetingName")) missing.push("会议名称");
      if (!valueOf("entity.meetingAddress")) missing.push("会议地址");
    }
    const embodies = (data.embodyTypes || data.embodyTypeIds || []).map((item) => clean(item));
    if (embodies.some((item) => /^(SCI|SCIE)$/i.test(item))) {
      if (!valueOf("entity.sciPartition")) missing.push("中科院分区大类");
      if (!valueOf("entity.sciPartitionSubclass")) missing.push("中科院分区小类");
      if (!valueOf("entity.factor")) missing.push("影响因子");
      if (!checkedValue("entity.isTop")) missing.push("是否TOP期刊");
    }
    const title = document.querySelector('select[name="entity.authors[0].titleId"]');
    if (!title?.value) missing.push("作者职称");
    if (!uploadReady("entity.fileIds")) missing.push("论文全文附件");
    if (!uploadReady("entity.searchCertificate")) missing.push("期刊分区或收录佐证材料");
    return missing;
  };

  const watchStep1Completion = (data) => {
    if (reviewReached()) return;
    stopStep1Watcher();
    const end = Date.now() + 10 * 60 * 1000;
    step1CompletionTimer = setInterval(() => {
      if (reviewReached() || Date.now() > end || currentStep() !== 1) {
        stopStep1Watcher();
        return;
      }
      if (step1Ready(data).length) return;
      stopStep1Watcher();
      clickButton("下一步", true);
    }, 800);
  };

  const autoAdvance = async (data, step, done, skipped, defaults) => {
    if (reviewReached()) return;
    const enabled = data.autoAdvance !== false && data.auto_advance !== false;
    if (!enabled) {
      announce(
        `第 ${step}/4 步字段已填写。\n已完成：${done.join("、") || "无"}\n` +
          (skipped.length ? `需核对：${skipped.join("；")}\n` : "") +
          "已按配置停在当前页，未点击“下一步”。",
        { progress: `${step}/4` }
      );
      return;
    }
    if (step === 1) {
      const missing = step1Ready(data);
      if (missing.length) {
        announce(
          `第 1/4 步已尽量预填，暂不自动进入下一步。\n已完成：${done.join("、") || "无"}\n` +
            `还需补充：${missing.join("、")}\n` +
            (defaults.length ? `默认值：${defaults.join("；")}\n` : "") +
            (skipped.length ? `需核对：${skipped.join("；")}\n` : "") +
            "补齐上述内容后，可点击页面“下一步”继续。",
          { error: true, progress: "1/4" }
        );
        watchStep1Completion(data);
        return;
      }
    }
    announce(
      `第 ${step}/4 步字段已填写，正在进入下一步。\n已完成：${done.join("、") || "无"}\n` +
        (skipped.length ? `需核对：${skipped.join("；")}` : ""),
      { progress: `${step}/4` }
    );
    await wait(350);
    if (reviewReached()) return;
    if (!clickButton("下一步", true)) {
      announce(`第 ${step}/4 步未找到“下一步”按钮，请手动继续并核对页面。`, {
        error: true,
        progress: `${step}/4`
      });
      return;
    }
    await wait(2500);
    if (currentStep() === step) {
      const errors = visibleErrors();
      announce(
        `第 ${step}/4 步点击“下一步”后仍停留在当前页。` +
          (errors.length ? `\n页面提示：${errors.join("；")}` : "\n请检查页面中的必填项。"),
        { error: true, progress: `${step}/4` }
      );
    }
  };

  const reviewStep = async (data) => {
    stopStep1Watcher();
    try {
      sessionStorage.setItem(REVIEW_REACHED_KEY, "1");
    } catch {}
    await clearPendingTask();
    const submit = findButton("提交", true);
    if (submit) {
      submit.style.outline = "3px solid #d97706";
      submit.style.outlineOffset = "2px";
    }
    announce(
      "四步信息已填写完成，并已由科研系统暂存。\n" +
        "请核对论文、作者、收录和依托项目信息。\n" +
        "最终请由本人点击页面“提交”；小海不会自动提交。",
      { progress: "4/4 · 待本人提交" }
    );
  };

  const navigateToForm = async () => {
    announce("已接收科研论文登记任务。正在定位论文登记入口；如尚未登录，请先完成学校统一认证。", {
      progress: "定位入口"
    });
    const end = Date.now() + 30000;
    while (Date.now() < end) {
      if (document.querySelector('input[name="entity.name"]')) return true;
      const anchors = [...document.querySelectorAll("a[href]")].filter(visible);
      const serviceHall = anchors.find((anchor) => clean(anchor.innerText) === "服务大厅");
      if (serviceHall?.href) {
        location.assign(serviceHall.href);
        return false;
      }
      const paperService = anchors.find(
        (anchor) =>
          norm(anchor.innerText).startsWith(norm("论文登记")) &&
          anchor.href.includes(`entity.id=${RESEARCH_SERVICE_ID}`)
      );
      if (paperService?.href) {
        location.assign(paperService.href);
        return false;
      }
      const start = findButton("立即办理", true);
      if (start) {
        if (start.tagName === "A" && start.href) location.assign(start.href);
        else start.click();
        return false;
      }
      await wait(500);
    }
    const ck = new URL(location.href).searchParams.get("ck");
    if (ck && location.hostname === "kyxt.hainanu.edu.cn") {
      announce("暂时无法从当前页面定位论文登记入口，请从“服务大厅”进入“论文登记”。", {
        error: true,
        progress: "定位入口"
      });
      return false;
    }
    if (location.hostname === "kyxt.hainanu.edu.cn" && location.pathname === "/") {
      location.assign("https://kyxt.hainanu.edu.cn/userAction!do_casLogin.action");
      return false;
    }
    announce("当前页面尚未显示论文登记入口。请完成登录或手动进入“论文登记”，扩展会继续接管。", {
      error: true,
      progress: "等待入口"
    });
    return false;
  };

  const run = async (data) => {
    if (reviewReached()) return;
    const step = currentStep();
    const files = researchFiles(data);
    if (!step) {
      await navigateToForm();
      return;
    }
    if (step === 1) {
      await waitForForm();
      const result = await fillStep1(data, files);
      await autoAdvance(data, 1, result.done, result.skipped, result.defaults);
      return;
    }
    if (step === 2) {
      const result = await fillStep2(data, files);
      await autoAdvance(data, 2, result.done, result.skipped, []);
      return;
    }
    if (step === 3) {
      const result = await fillStep3(data);
      await autoAdvance(data, 3, result.done, result.skipped, []);
      return;
    }
    await reviewStep(data);
  };

  const storeDirectTask = async (normalized) => {
    await chrome.runtime
      .sendMessage({
        type: "APPLY_STORE_PENDING",
        serviceId: SERVICE_ID,
        data: {
          ...normalized.data,
          files: normalized.files || [],
          autoAdvance:
            normalized.autoAdvance ??
            normalized.data.autoAdvance ??
            normalized.data.auto_advance ??
            true,
          stopBeforeSubmit: true
        }
      })
      .catch(() => {});
  };

  const clearDirectToken = () => {
    try {
      const url = new URL(location.href);
      url.searchParams.delete("applyPrefill");
      if (url.hash.includes("applyPrefill=")) url.hash = "";
      history.replaceState(null, "", url.toString());
    } catch {}
  };

  const boot = async () => {
    if (location.hostname !== "kyxt.hainanu.edu.cn") return;
    if (globalThis.__haiResearchAutoStarted) return;
    globalThis.__haiResearchAutoStarted = true;

    const direct = globalThis.HaiAgentPrefill?.parseUrl(location.href);
    if (direct?.serviceId === SERVICE_ID && direct.data) {
      clearReviewReached();
      const data = {
        ...direct.data,
        prefillTaskId: direct.data.prefillTaskId || createTaskId(),
        files: direct.files || [],
        autoAdvance: direct.autoAdvance ?? direct.data.autoAdvance ?? true,
        stopBeforeSubmit: true
      };
      await storeDirectTask({ ...direct, data });
      clearDirectToken();
      await run(data);
      return;
    }

    const pending = await chrome.runtime.sendMessage({ type: "APPLY_GET_PENDING" }).catch(() => null);
    let data = pending?.data;
    if (!data || (data.serviceId || pending.serviceId) !== SERVICE_ID) return;
    if (reviewReached()) {
      await clearPendingTask();
      return;
    }
    if (!data.prefillTaskId) {
      data = { ...data, serviceId: SERVICE_ID, prefillTaskId: createTaskId() };
      await chrome.runtime
        .sendMessage({ type: "APPLY_STORE_PENDING", serviceId: SERVICE_ID, data })
        .catch(() => {});
    }
    await run({ ...data, serviceId: SERVICE_ID });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
